import React, { useState, useEffect } from 'react';
import { User, FileText, Phone, Mail, MapPin, ExternalLink, AlertCircle, Edit2, CheckCircle2, Package, DollarSign, CreditCard, Link as LinkIcon, Search, Plus, X, Tag } from 'lucide-react';

const CW_CONFIG = {
  url: 'https://crm.xtremediagnostics.com',
  token: '26LLYTAZb4zKv5iU6swCTnvY'
};

const DB_CONFIG = {
  url: 'https://api-datos.xtremediagnostics.com'
};

interface Cliente {
  id: string;
  nombre: string;
  email: string;
  telefono: string;
  telefonos_vinculados: string[];
  direccion: string;
  rfc: string;
  tipo: 'Empresa' | 'Particular';
}

interface Cotizacion {
  id: string;
  fecha: string;
  monto: number;
  estado: string;
  desc: string;
  folio: string;
}

export default function ClienteResumenApp({ onOpenApp }: { onOpenApp?: (appId: string) => void }) {
  const [isEditing, setIsEditing] = useState(false);
  const [clienteData, setClienteData] = useState<Cliente>({
    id: 'Pendiente',
    nombre: 'Cargando...',
    email: 'Pendiente',
    telefono: 'Pendiente',
    telefonos_vinculados: [],
    direccion: 'Pendiente',
    rfc: 'Pendiente',
    tipo: 'Empresa'
  });
  const [cotizaciones, setCotizaciones] = useState<Cotizacion[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isLinkModalOpen, setIsLinkModalOpen] = useState(false);
  const [linkPhoneInput, setLinkPhoneInput] = useState('');
  const [isSearching, setIsSearching] = useState(false);

  useEffect(() => {
    const fetchAll = async () => {
      setIsLoading(true);
      const params = new URLSearchParams(window.location.search);
      let urlCid = params.get('contact_id');
      let urlConvId = params.get('conversation_id');

      // Try to get conversation ID from referrer if not in URL
      if (!urlConvId) {
        const match = document.referrer.match(/conversations\/(\d+)/);
        if (match) urlConvId = match[1];
      }
      
      // Try to get conversation ID from parent window URL if possible
      if (!urlConvId) {
        try {
          if (window.parent !== window && window.parent.location.href) {
            const match = window.parent.location.href.match(/conversations\/(\d+)/);
            if (match) urlConvId = match[1];
          }
        } catch (e) {}
      }

      let finalCid = urlCid;

      if (!finalCid && urlConvId) {
        try {
          const res = await fetch(`${CW_CONFIG.url}/api/v1/accounts/1/conversations/${urlConvId}`, {
            headers: { 'api_access_token': CW_CONFIG.token }
          });
          const data = await res.json();
          if (data.meta?.sender?.id) {
            finalCid = data.meta.sender.id.toString();
          }
        } catch (e) {
          console.warn("No se pudo obtener el contact_id de la conversación", e);
        }
      }

      if (finalCid) {
        // Fetch Client
        try {
          const res = await fetch(`${CW_CONFIG.url}/api/v1/accounts/1/contacts/${finalCid}`, {
            headers: { 'api_access_token': CW_CONFIG.token }
          });
          if (res.ok) {
            const contentType = res.headers.get("content-type");
            if (contentType && contentType.indexOf("application/json") !== -1) {
              const data = await res.json();
              const payload = data.payload;
              if (payload) {
                setClienteData({
                  id: payload.id ? payload.id.toString() : 'Pendiente',
                  nombre: payload.name || 'Pendiente',
                  email: payload.email || 'Pendiente',
                  telefono: payload.phone_number || 'Pendiente',
                  telefonos_vinculados: [],
                  direccion: payload.custom_attributes?.direccion || 'Pendiente',
                  rfc: payload.custom_attributes?.rfc || 'Pendiente',
                  tipo: payload.custom_attributes?.tipo_cliente === 'Particular' ? 'Particular' : 'Empresa'
                });
              }
            }
          }
        } catch (e) {
          console.error("Error fetching client", e);
        }

        // Fetch Cotizaciones
        try {
          const resHist = await fetch(`${DB_CONFIG.url}/cotizaciones?contact_id=eq.${finalCid}&order=created_at.desc`);
          if (resHist.ok) {
            const contentType = resHist.headers.get("content-type");
            if (contentType && contentType.indexOf("application/json") !== -1) {
              const dataHist = await resHist.json();
              if (Array.isArray(dataHist)) {
                const mappedCots = dataHist.map((d: any) => ({
                  id: d.id ? d.id.toString() : Math.random().toString(),
                  folio: d.detalles?.folio || (d.id ? d.id.toString() : 'S/F'),
                  fecha: d.created_at ? new Date(d.created_at).toLocaleDateString('es-MX') : 'Pendiente',
                  monto: d.monto || 0,
                  estado: d.detalles?.isPaid ? 'Pagada' : 'Pendiente',
                  desc: d.detalles?.items?.[0]?.name || 'Cotización'
                }));
                setCotizaciones(mappedCots);
              }
            }
          }
        } catch (e) {
          console.error("Error fetching history", e);
        }
      } else {
        setClienteData(prev => ({ ...prev, nombre: 'No se encontró contacto' }));
      }
      setIsLoading(false);
    };

    fetchAll();
  }, []);

  const handleSave = () => {
    setIsEditing(false);
    console.log('Guardando datos del cliente:', clienteData);
  };

  const handleLinkPhone = () => {
    if (!linkPhoneInput.trim()) return;
    setIsSearching(true);
    // Simular búsqueda y vinculación
    setTimeout(() => {
      setClienteData(prev => ({
        ...prev,
        telefonos_vinculados: [...prev.telefonos_vinculados, linkPhoneInput]
      }));
      setLinkPhoneInput('');
      setIsSearching(false);
      setIsLinkModalOpen(false);
    }, 800);
  };

  const hasPaidQuote = cotizaciones.some(c => c.estado === 'Pagada');
  const hasPendingQuote = cotizaciones.some(c => c.estado === 'Pendiente');
  const totalPagado = cotizaciones.filter(c => c.estado === 'Pagada').reduce((acc, curr) => acc + curr.monto, 0);
  const totalPendiente = cotizaciones.filter(c => c.estado === 'Pendiente').reduce((acc, curr) => acc + curr.monto, 0);

  let classificationTag = null;
  if (hasPaidQuote) {
    classificationTag = (
      <span className="text-[10px] font-bold bg-emerald-100 text-emerald-700 px-2 py-0.5 rounded-full flex items-center gap-1">
        <CheckCircle2 className="w-3 h-3" /> Cliente Xtreme Diagnostics
      </span>
    );
  } else if (hasPendingQuote) {
    classificationTag = (
      <span className="text-[10px] font-bold bg-amber-100 text-amber-700 px-2 py-0.5 rounded-full flex items-center gap-1">
        <AlertCircle className="w-3 h-3" /> Seguimiento de cotización pendiente
      </span>
    );
  } else {
    classificationTag = (
      <span className="text-[10px] font-bold bg-slate-100 text-slate-600 px-2 py-0.5 rounded-full flex items-center gap-1">
        <User className="w-3 h-3" /> Prospecto
      </span>
    );
  }

  return (
    <div className="h-full flex flex-col bg-slate-100 overflow-hidden text-slate-800">
      {/* Context Banner */}
      <div className="bg-white border-b border-slate-200 px-4 py-2 flex items-center justify-between shrink-0 shadow-sm z-10">
        <div className="flex items-center gap-3 text-xs">
          <div className="flex items-center gap-1.5 bg-xtreme-cyan/10 text-xtreme-cyan px-2 py-1 rounded font-semibold uppercase tracking-wider">
            <User className="w-3.5 h-3.5" /> Contexto
          </div>
          <span className="font-bold text-slate-700 text-sm">{clienteData.nombre}</span>
          {classificationTag}
          {clienteData.telefono !== 'Pendiente' && (
            <span className="text-slate-500 flex items-center gap-1 bg-slate-100 px-2 py-0.5 rounded-full">
              <Phone className="w-3 h-3" /> {clienteData.telefono}
            </span>
          )}
        </div>
        <div className="flex gap-2">
          <button 
            onClick={() => setIsLinkModalOpen(true)}
            className="flex items-center gap-1.5 text-xs font-semibold bg-indigo-50 text-indigo-600 hover:bg-indigo-100 px-3 py-1.5 rounded-md transition-colors border border-indigo-100"
          >
            <LinkIcon className="w-3.5 h-3.5" /> Vincular Teléfono
          </button>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-4 no-scrollbar">
        <div className="max-w-7xl mx-auto flex flex-col lg:flex-row gap-4">
          
          {/* Left Column: Client Info (Compact) */}
          <div className="w-full lg:w-80 shrink-0 space-y-4">
            <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-4 relative">
              <button 
                onClick={() => isEditing ? handleSave() : setIsEditing(true)}
                className="absolute top-3 right-3 p-1.5 text-slate-400 hover:text-xtreme-cyan hover:bg-cyan-50 rounded-md transition-colors"
              >
                {isEditing ? <CheckCircle2 className="w-4 h-4 text-emerald-500" /> : <Edit2 className="w-4 h-4" />}
              </button>

              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 rounded-full bg-cyan-100 flex items-center justify-center border-2 border-white shadow-sm shrink-0">
                  <User className="w-6 h-6 text-cyan-600" />
                </div>
                <div className="flex-1 min-w-0">
                  {isEditing ? (
                    <input 
                      type="text" 
                      value={clienteData.nombre}
                      onChange={(e) => setClienteData({...clienteData, nombre: e.target.value})}
                      className="text-sm font-bold text-slate-800 border-b border-xtreme-cyan focus:outline-none bg-transparent w-full"
                    />
                  ) : (
                    <div className="flex flex-col gap-1">
                      <h2 className="text-sm font-bold text-slate-800 truncate" title={clienteData.nombre}>{clienteData.nombre}</h2>
                      <div className="self-start">{classificationTag}</div>
                    </div>
                  )}
                  <div className="flex items-center gap-2 mt-1">
                    <span className="text-[10px] font-mono text-slate-500 bg-slate-100 px-1.5 rounded">{clienteData.id}</span>
                    <span className="text-[10px] font-medium bg-blue-50 text-blue-600 px-1.5 rounded">{clienteData.tipo}</span>
                  </div>
                </div>
              </div>

              <div className="space-y-2.5">
                {(isEditing || clienteData.email !== 'Pendiente') && (
                  <div className="flex items-start gap-2">
                    <Mail className="w-3.5 h-3.5 text-slate-400 mt-0.5 shrink-0" />
                    {isEditing ? (
                      <input type="email" value={clienteData.email} onChange={(e) => setClienteData({...clienteData, email: e.target.value})} className="w-full text-xs p-1 border border-slate-300 rounded focus:border-xtreme-cyan outline-none" placeholder="Email" />
                    ) : (
                      <div className="text-xs text-slate-600 truncate" title={clienteData.email}>{clienteData.email}</div>
                    )}
                  </div>
                )}
                
                {(isEditing || clienteData.telefono !== 'Pendiente') && (
                  <div className="flex items-start gap-2">
                    <Phone className="w-3.5 h-3.5 text-slate-400 mt-0.5 shrink-0" />
                    <div className="flex-1">
                      {isEditing ? (
                        <input type="text" value={clienteData.telefono} onChange={(e) => setClienteData({...clienteData, telefono: e.target.value})} className="w-full text-xs p-1 border border-slate-300 rounded focus:border-xtreme-cyan outline-none" placeholder="Teléfono" />
                      ) : (
                        <div className="text-xs text-slate-600 font-medium">{clienteData.telefono} <span className="text-[9px] text-emerald-500 ml-1">(Principal)</span></div>
                      )}
                      {/* Linked Phones */}
                      {clienteData.telefonos_vinculados.length > 0 && !isEditing && (
                        <div className="mt-1 space-y-1">
                          {clienteData.telefonos_vinculados.map((tel, idx) => (
                            <div key={idx} className="text-xs text-slate-500 flex items-center gap-1">
                              <LinkIcon className="w-3 h-3 text-indigo-400" /> {tel}
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>
                )}

                {(isEditing || clienteData.direccion !== 'Pendiente') && (
                  <div className="flex items-start gap-2">
                    <MapPin className="w-3.5 h-3.5 text-slate-400 mt-0.5 shrink-0" />
                    {isEditing ? (
                      <textarea value={clienteData.direccion} onChange={(e) => setClienteData({...clienteData, direccion: e.target.value})} className="w-full text-xs p-1 border border-slate-300 rounded focus:border-xtreme-cyan outline-none resize-none" rows={2} placeholder="Dirección" />
                    ) : (
                      <div className="text-xs text-slate-600 leading-tight">{clienteData.direccion}</div>
                    )}
                  </div>
                )}

                {(isEditing || clienteData.rfc !== 'Pendiente') && (
                  <div className="flex items-start gap-2">
                    <FileText className="w-3.5 h-3.5 text-slate-400 mt-0.5 shrink-0" />
                    {isEditing ? (
                      <input type="text" value={clienteData.rfc} onChange={(e) => setClienteData({...clienteData, rfc: e.target.value})} className="w-full text-xs p-1 border border-slate-300 rounded focus:border-xtreme-cyan outline-none uppercase" placeholder="RFC" />
                    ) : (
                      <div className="text-xs text-slate-600 font-mono">{clienteData.rfc}</div>
                    )}
                  </div>
                )}
              </div>
            </div>

            {/* Quick Stats Grid */}
            <div className="grid grid-cols-2 gap-3">
              <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-3 flex flex-col items-center justify-center">
                <DollarSign className="w-5 h-5 text-emerald-500 mb-1" />
                <div className="text-lg font-bold text-slate-800 leading-none">${totalPagado.toLocaleString()}</div>
                <div className="text-[9px] text-slate-500 font-bold uppercase tracking-wider mt-1">Pagado</div>
              </div>
              <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-3 flex flex-col items-center justify-center">
                <AlertCircle className="w-5 h-5 text-amber-500 mb-1" />
                <div className="text-lg font-bold text-slate-800 leading-none">${totalPendiente.toLocaleString()}</div>
                <div className="text-[9px] text-slate-500 font-bold uppercase tracking-wider mt-1">Pendiente</div>
              </div>
            </div>
          </div>

          {/* Right Column: Activity & History (Dense) */}
          <div className="flex-1 space-y-4 min-w-0">
            
            {/* Cotizaciones Section */}
            <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden flex flex-col">
              <div className="px-4 py-2.5 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
                <h3 className="text-sm font-bold text-slate-800 flex items-center gap-1.5">
                  <DollarSign className="w-4 h-4 text-emerald-500" /> Cotizaciones
                </h3>
                <button onClick={() => onOpenApp?.('cotizaciones')} className="text-[10px] font-bold uppercase tracking-wider text-xtreme-cyan hover:text-cyan-700">Ver todas</button>
              </div>
              <div className="divide-y divide-slate-100">
                {cotizaciones.length === 0 ? (
                  <div className="p-6 text-center text-slate-400 text-xs">
                    No hay cotizaciones para este cliente.
                  </div>
                ) : (
                  cotizaciones.map(cot => (
                    <div key={cot.id} onClick={() => onOpenApp?.('cotizaciones')} className="p-3 flex items-center justify-between hover:bg-slate-50 transition-colors group cursor-pointer">
                      <div className="flex-1 min-w-0 pr-4">
                        <div className="flex items-center gap-2 mb-0.5">
                          <span className="text-xs font-bold text-slate-800">{cot.folio}</span>
                          <span className={`text-[9px] px-1.5 py-0.5 rounded uppercase font-bold tracking-wider ${cot.estado === 'Pagada' ? 'bg-emerald-100 text-emerald-700' : 'bg-amber-100 text-amber-700'}`}>
                            {cot.estado}
                          </span>
                          <span className="text-[10px] text-slate-400 ml-auto">{cot.fecha}</span>
                        </div>
                        <div className="text-xs text-slate-600 truncate">{cot.desc}</div>
                      </div>
                      <div className="flex items-center gap-3 shrink-0">
                        <div className="text-sm font-bold text-slate-800">${cot.monto.toLocaleString()}</div>
                        {cot.estado === 'Pendiente' && (
                          <button className="text-[10px] flex items-center gap-1 bg-emerald-50 text-emerald-600 hover:bg-emerald-100 px-2 py-1 rounded border border-emerald-200 transition-colors opacity-0 group-hover:opacity-100">
                            <CreditCard className="w-3 h-3" /> Pagar
                          </button>
                        )}
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>

          </div>
        </div>
      </div>

      {/* Modal Vincular Teléfono */}
      {isLinkModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 backdrop-blur-sm p-4">
          <div className="bg-white rounded-xl shadow-xl w-full max-w-md overflow-hidden animate-in zoom-in-95 duration-200">
            <div className="px-4 py-3 border-b border-slate-100 flex items-center justify-between bg-slate-50">
              <h3 className="font-bold text-slate-800 flex items-center gap-2">
                <LinkIcon className="w-4 h-4 text-indigo-500" /> Vincular Nuevo Contacto
              </h3>
              <button onClick={() => setIsLinkModalOpen(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="p-5 space-y-4">
              <p className="text-xs text-slate-500">
                Busca un número de teléfono para vincular su historial (tickets, cotizaciones) a este cliente principal ({clienteData.nombre}).
              </p>
              
              <div>
                <label className="text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5 block">Número de Teléfono</label>
                <div className="relative">
                  <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input 
                    type="text" 
                    value={linkPhoneInput}
                    onChange={(e) => setLinkPhoneInput(e.target.value)}
                    placeholder="+52 81 0000 0000"
                    className="w-full pl-9 pr-4 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500"
                    autoFocus
                  />
                </div>
              </div>

              <div className="bg-indigo-50 border border-indigo-100 rounded-lg p-3 flex items-start gap-2">
                <AlertCircle className="w-4 h-4 text-indigo-600 shrink-0 mt-0.5" />
                <p className="text-[10px] text-indigo-800 leading-relaxed">
                  Al vincular, todas las conversaciones de Chatwoot y registros asociados a este número se mostrarán bajo el perfil de <strong>{clienteData.nombre}</strong>.
                </p>
              </div>
            </div>
            <div className="px-4 py-3 border-t border-slate-100 bg-slate-50 flex justify-end gap-2">
              <button 
                onClick={() => setIsLinkModalOpen(false)}
                className="px-4 py-2 text-xs font-bold text-slate-600 hover:bg-slate-200 rounded-lg transition-colors"
              >
                Cancelar
              </button>
              <button 
                onClick={handleLinkPhone}
                disabled={!linkPhoneInput.trim() || isSearching}
                className="px-4 py-2 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 disabled:cursor-not-allowed rounded-lg transition-colors flex items-center gap-2"
              >
                {isSearching ? (
                  <>Buscando...</>
                ) : (
                  <>Vincular Historial</>
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
