import React, { useState } from 'react';
import { Search, Plus, Filter, Clock, CheckCircle2, AlertCircle, MoreVertical, User, Phone } from 'lucide-react';

interface Ticket {
  id: string;
  cliente_id: string;
  titulo: string;
  estado: 'Abierto' | 'En Progreso' | 'Cerrado';
  prioridad: 'Baja' | 'Media' | 'Alta' | 'Urgente';
  fecha_creacion: string;
  agente_asignado: string;
}

// Mock del contexto de Chatwoot (Cliente actual)
const CURRENT_CLIENT_CONTEXT = {
  id: 'CLI-102',
  nombre: 'Transportes del Norte S.A.',
  telefono: '+52 81 1234 5678'
};

const mockTickets: Ticket[] = [
  { id: 'TKT-001', cliente_id: 'CLI-102', titulo: 'Problema con motor de arranque', estado: 'Abierto', prioridad: 'Alta', fecha_creacion: '2023-10-25', agente_asignado: 'Carlos M.' },
  { id: 'TKT-004', cliente_id: 'CLI-102', titulo: 'Mantenimiento preventivo flotilla', estado: 'En Progreso', prioridad: 'Media', fecha_creacion: '2023-10-20', agente_asignado: 'Ana R.' },
  { id: 'TKT-008', cliente_id: 'CLI-102', titulo: 'Cambio de balatas', estado: 'Cerrado', prioridad: 'Baja', fecha_creacion: '2023-09-15', agente_asignado: 'Luis G.' },
];

export default function TicketsSoporteApp() {
  const [searchTerm, setSearchTerm] = useState('');

  const getStatusColor = (estado: string) => {
    switch (estado) {
      case 'Abierto': return 'bg-red-100 text-red-700 border-red-200';
      case 'En Progreso': return 'bg-blue-100 text-blue-700 border-blue-200';
      case 'Cerrado': return 'bg-emerald-100 text-emerald-700 border-emerald-200';
      default: return 'bg-gray-100 text-gray-700 border-gray-200';
    }
  };

  const getPriorityColor = (prioridad: string) => {
    switch (prioridad) {
      case 'Urgente': return 'text-red-600 bg-red-50';
      case 'Alta': return 'text-orange-600 bg-orange-50';
      case 'Media': return 'text-blue-600 bg-blue-50';
      case 'Baja': return 'text-gray-600 bg-gray-50';
      default: return 'text-gray-600 bg-gray-50';
    }
  };

  return (
    <div className="h-full flex flex-col bg-slate-50">
      {/* Context Banner */}
      <div className="bg-xtreme-blue/10 border-b border-xtreme-blue/20 px-6 py-2 flex items-center justify-between shrink-0">
        <div className="flex items-center gap-4 text-sm">
          <span className="font-semibold text-xtreme-blue flex items-center gap-1">
            <User className="w-4 h-4" /> Contexto Activo:
          </span>
          <span className="text-slate-700 font-medium">{CURRENT_CLIENT_CONTEXT.nombre}</span>
          <span className="text-slate-500 flex items-center gap-1">
            <Phone className="w-3 h-3" /> {CURRENT_CLIENT_CONTEXT.telefono}
          </span>
        </div>
      </div>

      {/* Header */}
      <div className="bg-white border-b border-slate-200 px-6 py-4 flex items-center justify-between shrink-0">
        <div>
          <h1 className="text-2xl font-bold text-slate-800 font-tech">Tickets del Cliente</h1>
          <p className="text-sm text-slate-500">Historial de soporte para {CURRENT_CLIENT_CONTEXT.nombre}</p>
        </div>
        <button className="bg-xtreme-blue hover:bg-blue-700 text-white px-4 py-2 rounded-lg flex items-center gap-2 font-medium transition-colors shadow-sm">
          <Plus className="w-4 h-4" />
          Nuevo Ticket
        </button>
      </div>

      {/* Toolbar */}
      <div className="px-6 py-4 flex items-center gap-4 shrink-0">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input 
            type="text" 
            placeholder="Buscar en los tickets de este cliente..." 
            className="w-full pl-10 pr-4 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-xtreme-blue/20 focus:border-xtreme-blue transition-all"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <button className="flex items-center gap-2 px-4 py-2 border border-slate-200 rounded-lg text-slate-600 hover:bg-slate-50 transition-colors bg-white">
          <Filter className="w-4 h-4" />
          Filtros
        </button>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-auto px-6 pb-6">
        <div className="bg-white border border-slate-200 rounded-xl shadow-sm overflow-hidden">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-slate-500 text-xs uppercase tracking-wider font-semibold">
                <th className="px-6 py-4">ID Ticket</th>
                <th className="px-6 py-4">Título</th>
                <th className="px-6 py-4">Estado</th>
                <th className="px-6 py-4">Prioridad</th>
                <th className="px-6 py-4">Agente</th>
                <th className="px-6 py-4">Fecha</th>
                <th className="px-6 py-4 text-right">Acciones</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {mockTickets.map((ticket) => (
                <tr key={ticket.id} className="hover:bg-slate-50 transition-colors group">
                  <td className="px-6 py-4">
                    <span className="font-mono text-sm font-medium text-slate-700">{ticket.id}</span>
                  </td>
                  <td className="px-6 py-4">
                    <div className="font-medium text-slate-900">{ticket.titulo}</div>
                  </td>
                  <td className="px-6 py-4">
                    <span className={`inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium border ${getStatusColor(ticket.estado)}`}>
                      {ticket.estado === 'Abierto' && <AlertCircle className="w-3 h-3 mr-1" />}
                      {ticket.estado === 'En Progreso' && <Clock className="w-3 h-3 mr-1" />}
                      {ticket.estado === 'Cerrado' && <CheckCircle2 className="w-3 h-3 mr-1" />}
                      {ticket.estado}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <span className={`inline-flex px-2 py-1 rounded text-xs font-medium ${getPriorityColor(ticket.prioridad)}`}>
                      {ticket.prioridad}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-sm text-slate-600">
                    {ticket.agente_asignado}
                  </td>
                  <td className="px-6 py-4 text-sm text-slate-500">
                    {ticket.fecha_creacion}
                  </td>
                  <td className="px-6 py-4 text-right">
                    <button className="p-1.5 text-slate-400 hover:text-xtreme-blue hover:bg-blue-50 rounded transition-colors">
                      <MoreVertical className="w-5 h-5" />
                    </button>
                  </td>
                </tr>
              ))}
              {mockTickets.length === 0 && (
                <tr>
                  <td colSpan={7} className="px-6 py-8 text-center text-slate-500">
                    No hay tickets registrados para este cliente.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
