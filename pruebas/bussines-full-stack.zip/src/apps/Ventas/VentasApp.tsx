import React, { useState, useEffect } from 'react';
import { 
  TrendingUp, DollarSign, Users, Calendar, 
  BarChart3, PieChart, Activity, ArrowUpRight,
  Package, FileText, CheckCircle2, Clock, CreditCard,
  LayoutDashboard, List, CheckSquare, Settings, ChevronLeft, ChevronRight,
  ShieldAlert, ShieldCheck, Plus
} from 'lucide-react';

const DB_CONFIG = {
  url: "https://api-datos.xtremediagnostics.com"
};

interface Cotizacion {
  id: number;
  contact_id: string;
  folio: string;
  monto: number;
  agente: string;
  created_at: string;
  detalles: any;
}

interface CommissionRule {
  id: string;
  name: string;
  type: 'agent' | 'concept' | 'amount';
  condition: string;
  percentage: number;
}

export default function VentasApp({ username }: { username?: string }) {
  const [sales, setSales] = useState<Cotizacion[]>([]);
  const [loading, setLoading] = useState(true);
  
  // Tabs: pagadas, dashboard, generadas, comisiones
  const [activeTab, setActiveTab] = useState<'pagadas' | 'dashboard' | 'generadas' | 'comisiones'>('pagadas');
  
  // Time filtering
  const [timeFilterType, setTimeFilterType] = useState<'week' | 'month'>('week');
  const [currentDateOffset, setCurrentDateOffset] = useState(0);
  
  // CEO Mode
  const [isCEO, setIsCEO] = useState(username?.toLowerCase() === 'ceo' || username?.toLowerCase() === 'admin');

  // Payment Modal State
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [selectedCot, setSelectedCot] = useState<Cotizacion | null>(null);
  const [paymentDate, setPaymentDate] = useState('');
  const [paymentMethod, setPaymentMethod] = useState('Transferencia');
  const [paymentNotes, setPaymentNotes] = useState('');

  // Commission Rules State
  const [commissionRules, setCommissionRules] = useState<CommissionRule[]>([
    { id: '1', name: 'Comisión Valeria', type: 'agent', condition: 'valeria', percentage: 1.4 },
    { id: '2', name: 'Comisión Base', type: 'amount', condition: '0', percentage: 0 }
  ]);
  const [showRuleModal, setShowRuleModal] = useState(false);
  const [editingRule, setEditingRule] = useState<CommissionRule | null>(null);

  useEffect(() => {
    fetchSales();
  }, []);

  const fetchSales = async () => {
    try {
      setLoading(true);
      // Fetch a larger limit to allow local filtering across weeks/months
      const res = await fetch(`${DB_CONFIG.url}/cotizaciones?select=id,contact_id,created_at,detalles,monto,agente&order=created_at.desc&limit=2000`);
      if (res.ok) {
        const data = await res.json();
        if (Array.isArray(data)) {
          setSales(data);
        }
      }
    } catch (error) {
      console.error("Error fetching sales:", error);
    } finally {
      setLoading(false);
    }
  };

  // Date Filtering Logic
  const getFilterDates = () => {
    const now = new Date();
    if (timeFilterType === 'week') {
      const day = now.getDay();
      const diff = now.getDate() - day + (day === 0 ? -6 : 1); // Monday
      const startOfWeek = new Date(now.setDate(diff));
      startOfWeek.setHours(0, 0, 0, 0);
      startOfWeek.setDate(startOfWeek.getDate() + (currentDateOffset * 7));
      
      const endOfWeek = new Date(startOfWeek);
      endOfWeek.setDate(endOfWeek.getDate() + 6);
      endOfWeek.setHours(23, 59, 59, 999);
      
      return { start: startOfWeek, end: endOfWeek };
    } else {
      const startOfMonth = new Date(now.getFullYear(), now.getMonth() + currentDateOffset, 1);
      const endOfMonth = new Date(now.getFullYear(), now.getMonth() + currentDateOffset + 1, 0);
      endOfMonth.setHours(23, 59, 59, 999);
      return { start: startOfMonth, end: endOfMonth };
    }
  };

  const { start: filterStart, end: filterEnd } = getFilterDates();

  const filteredSales = sales.filter(s => {
    const date = new Date(s.created_at);
    return date >= filterStart && date <= filterEnd;
  });

  const paidSales = filteredSales.filter(s => s.detalles?.isPaid);
  const pendingSales = filteredSales.filter(s => !s.detalles?.isPaid);

  // Metrics
  const totalRevenue = paidSales.reduce((acc, curr) => acc + (curr.monto || curr.detalles?.total || 0), 0);
  const totalPending = pendingSales.reduce((acc, curr) => acc + (curr.monto || curr.detalles?.total || 0), 0);
  
  // Agent Sales
  const agentSales = paidSales.reduce((acc: any, curr) => {
    const agent = curr.agente || curr.detalles?.vendedor || 'Desconocido';
    if (!acc[agent]) acc[agent] = { count: 0, total: 0, commission: 0 };
    acc[agent].count += 1;
    const total = curr.monto || curr.detalles?.total || 0;
    acc[agent].total += total;

    // Calculate commission for this sale
    let saleCommission = 0;
    const items = curr.detalles?.items || [];
    
    // Find matching rule (first match wins)
    const rule = commissionRules.find(r => {
      if (r.type === 'agent') return agent.toLowerCase().includes(r.condition.toLowerCase());
      if (r.type === 'amount') return total >= parseFloat(r.condition || '0');
      if (r.type === 'concept') return items.some((i: any) => i.nombre?.toLowerCase().includes(r.condition.toLowerCase()));
      return false;
    });

    if (rule) {
      saleCommission = total * (rule.percentage / 100);
    }

    acc[agent].commission += saleCommission;

    return acc;
  }, {});

  const handleConfirmPayment = async () => {
    if (!selectedCot) return;
    
    const updatedDetalles = {
      ...selectedCot.detalles,
      isPaid: true,
      paymentDate,
      paymentMethod,
      paymentNotes
    };

    try {
      const res = await fetch(`${DB_CONFIG.url}/cotizaciones?id=eq.${selectedCot.id}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ detalles: updatedDetalles })
      });

      if (res.ok) {
        setSales(prev => prev.map(c => 
          c.id === selectedCot.id ? { ...c, detalles: updatedDetalles } : c
        ));
        setShowPaymentModal(false);
        setSelectedCot(null);
      } else {
        alert("Error al actualizar el estado de pago.");
      }
    } catch (e) {
      alert("Error al actualizar el estado de pago.");
    }
  };

  const handleMarkAccountingReceived = async (cot: Cotizacion) => {
    if (!confirm("¿Confirmar que contabilidad (Roxana) ya recibió este pago?")) return;

    const updatedDetalles = {
      ...cot.detalles,
      pagoRecibidoContabilidad: true,
      fechaRecibidoContabilidad: new Date().toISOString()
    };

    try {
      const res = await fetch(`${DB_CONFIG.url}/cotizaciones?id=eq.${cot.id}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ detalles: updatedDetalles })
      });

      if (res.ok) {
        setSales(prev => prev.map(c => 
          c.id === cot.id ? { ...c, detalles: updatedDetalles } : c
        ));
      } else {
        alert("Error al actualizar.");
      }
    } catch (e) {
      alert("Error al actualizar.");
    }
  };

  const formatDateLabel = () => {
    const opts: Intl.DateTimeFormatOptions = { day: 'numeric', month: 'short' };
    if (timeFilterType === 'week') {
      return `${filterStart.toLocaleDateString('es-MX', opts)} - ${filterEnd.toLocaleDateString('es-MX', opts)}`;
    } else {
      return filterStart.toLocaleDateString('es-MX', { month: 'long', year: 'numeric' }).toUpperCase();
    }
  };

  if (loading && sales.length === 0) {
    return (
      <div className="h-full flex items-center justify-center bg-[#0f1014]">
        <div className="w-8 h-8 border-2 border-purple-500 border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  return (
    <div className="h-full flex flex-col bg-[#0f1014] text-slate-300 font-sans overflow-hidden relative">
      
      {/* Top Header */}
      <div className="px-6 py-4 border-b border-[#1f2026] flex items-center justify-between shrink-0 bg-[#15161a]">
        <div className="flex items-center gap-4">
          <div className="w-10 h-10 bg-purple-500/10 rounded-xl flex items-center justify-center border border-purple-500/20">
            <TrendingUp className="text-purple-400 w-5 h-5" />
          </div>
          <div>
            <h1 className="text-lg font-bold text-white tracking-wide">XtremeOS <span className="text-purple-400">Ventas</span></h1>
            <p className="text-xs text-slate-500 uppercase tracking-widest">Sistema de Control</p>
          </div>
        </div>

        {/* Date Controls */}
        <div className="flex items-center gap-4">
          <div className="flex bg-[#1f2026] rounded-lg p-1 border border-[#2a2b32]">
            <button 
              onClick={() => { setTimeFilterType('week'); setCurrentDateOffset(0); }}
              className={`px-3 py-1.5 text-xs font-bold rounded-md transition-colors ${timeFilterType === 'week' ? 'bg-[#2a2b32] text-white' : 'text-slate-500 hover:text-slate-300'}`}
            >
              SEMANA
            </button>
            <button 
              onClick={() => { setTimeFilterType('month'); setCurrentDateOffset(0); }}
              className={`px-3 py-1.5 text-xs font-bold rounded-md transition-colors ${timeFilterType === 'month' ? 'bg-[#2a2b32] text-white' : 'text-slate-500 hover:text-slate-300'}`}
            >
              MES
            </button>
          </div>

          <div className="flex items-center gap-2 bg-[#1f2026] rounded-lg p-1 border border-[#2a2b32]">
            <button onClick={() => setCurrentDateOffset(prev => prev - 1)} className="p-1.5 hover:bg-[#2a2b32] rounded-md text-slate-400 hover:text-white transition-colors">
              <ChevronLeft className="w-4 h-4" />
            </button>
            <span className="text-xs font-bold text-white min-w-[120px] text-center">
              {formatDateLabel()}
            </span>
            <button onClick={() => setCurrentDateOffset(prev => prev + 1)} className="p-1.5 hover:bg-[#2a2b32] rounded-md text-slate-400 hover:text-white transition-colors" disabled={currentDateOffset >= 0}>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Main Content Area */}
      <div className="flex-1 overflow-y-auto p-6 pb-32">
        <div className="max-w-6xl mx-auto">
          
          {/* TAB: PAGADAS (DEFAULT) */}
          {activeTab === 'pagadas' && (
            <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-bold text-white flex items-center gap-2">
                  <CheckCircle2 className="text-emerald-400 w-5 h-5" />
                  Cotizaciones Pagadas
                </h2>
                <div className="text-sm text-slate-400">
                  Total: <span className="text-white font-bold">${totalRevenue.toLocaleString('es-MX', { minimumFractionDigits: 2 })}</span>
                </div>
              </div>

              <div className="bg-[#15161a] border border-[#1f2026] rounded-2xl overflow-x-auto overflow-y-hidden">
                <table className="w-full text-left text-sm min-w-[600px]">
                  <thead className="bg-[#1a1b20] text-xs uppercase text-slate-500 font-bold tracking-wider">
                    <tr>
                      <th className="px-4 py-3">Folio / Cliente</th>
                      <th className="px-4 py-3">Fecha Pago</th>
                      <th className="px-4 py-3">Agente</th>
                      <th className="px-4 py-3 text-right">Monto</th>
                      <th className="px-4 py-3 text-center">Documentos</th>
                      <th className="px-4 py-3 text-center">Estatus Contable</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#1f2026]">
                    {paidSales.length === 0 ? (
                      <tr><td colSpan={6} className="px-6 py-12 text-center text-slate-500">No hay cotizaciones pagadas en este periodo.</td></tr>
                    ) : (
                      paidSales.map(sale => (
                        <tr key={sale.id} className="hover:bg-[#1a1b20] transition-colors">
                          <td className="px-4 py-3">
                            <div className="font-bold text-white">{sale.detalles?.folio || 'S/F'}</div>
                            <div className="text-xs text-slate-500">{sale.detalles?.cliente?.nombre || 'Cliente Desconocido'}</div>
                          </td>
                          <td className="px-4 py-3">
                            <div className="text-slate-300">{sale.detalles?.paymentDate ? new Date(sale.detalles.paymentDate).toLocaleDateString('es-MX') : '-'}</div>
                            <div className="text-[10px] text-slate-500">{sale.detalles?.paymentMethod}</div>
                          </td>
                          <td className="px-4 py-3 text-slate-300">{sale.agente || sale.detalles?.vendedor || 'Sin Agente'}</td>
                          <td className="px-4 py-3 text-right font-bold text-emerald-400">
                            ${(sale.monto || sale.detalles?.total || 0).toLocaleString('es-MX', { minimumFractionDigits: 2 })}
                          </td>
                          <td className="px-4 py-3 text-center">
                            <div className="flex items-center justify-center gap-2">
                              {sale.detalles?.shipping_label_url && (
                                <a 
                                  href={sale.detalles.shipping_label_url} 
                                  target="_blank" 
                                  rel="noopener noreferrer"
                                  className="p-1.5 rounded-lg bg-blue-500/10 text-blue-400 hover:bg-blue-500/20 transition-colors"
                                  title="Ver Etiqueta de Envío"
                                >
                                  <FileText size={14} />
                                </a>
                              )}
                              {sale.detalles?.invoice_url && (
                                <a 
                                  href={sale.detalles.invoice_url} 
                                  target="_blank" 
                                  rel="noopener noreferrer"
                                  className="p-1.5 rounded-lg bg-emerald-500/10 text-emerald-400 hover:bg-emerald-500/20 transition-colors"
                                  title="Ver Factura"
                                >
                                  <FileText size={14} />
                                </a>
                              )}
                              {!sale.detalles?.shipping_label_url && !sale.detalles?.invoice_url && (
                                <span className="text-[10px] text-slate-600 italic">Sin docs</span>
                              )}
                            </div>
                          </td>
                          <td className="px-4 py-3 text-center">
                            {sale.detalles?.pagoRecibidoContabilidad ? (
                              <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-emerald-500/10 text-emerald-400 text-[10px] font-bold uppercase tracking-wider border border-emerald-500/20">
                                <ShieldCheck className="w-3 h-3" /> Recibido
                              </span>
                            ) : (
                              isCEO ? (
                                <button 
                                  onClick={() => handleMarkAccountingReceived(sale)}
                                  className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg bg-amber-500/10 text-amber-400 hover:bg-amber-500/20 text-xs font-bold transition-colors border border-amber-500/20"
                                >
                                  Marcar Recibido
                                </button>
                              ) : (
                                <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-amber-500/10 text-amber-400 text-[10px] font-bold uppercase tracking-wider border border-amber-500/20">
                                  Pendiente
                                </span>
                              )
                            )}
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* TAB: DASHBOARD */}
          {activeTab === 'dashboard' && (
            <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
              <h2 className="text-xl font-bold text-white flex items-center gap-2 mb-6">
                <LayoutDashboard className="text-purple-400 w-5 h-5" />
                Tablero Global
              </h2>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="bg-[#15161a] border border-[#1f2026] rounded-2xl p-5 relative overflow-hidden">
                  <div className="absolute top-0 right-0 w-24 h-24 bg-emerald-500/5 rounded-bl-full -mr-6 -mt-6"></div>
                  <p className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">Ingresos Pagados</p>
                  <h3 className="text-2xl font-black text-white mb-2">${totalRevenue.toLocaleString('es-MX', { minimumFractionDigits: 2 })}</h3>
                  <div className="text-[10px] text-emerald-400 font-medium">{paidSales.length} cotizaciones concretadas</div>
                </div>

                <div className="bg-[#15161a] border border-[#1f2026] rounded-2xl p-5 relative overflow-hidden">
                  <div className="absolute top-0 right-0 w-24 h-24 bg-amber-500/5 rounded-bl-full -mr-6 -mt-6"></div>
                  <p className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">Por Cobrar</p>
                  <h3 className="text-2xl font-black text-white mb-2">${totalPending.toLocaleString('es-MX', { minimumFractionDigits: 2 })}</h3>
                  <div className="text-[10px] text-amber-400 font-medium">{pendingSales.length} cotizaciones pendientes</div>
                </div>

                <div className="bg-[#15161a] border border-[#1f2026] rounded-2xl p-5 relative overflow-hidden">
                  <div className="absolute top-0 right-0 w-24 h-24 bg-blue-500/5 rounded-bl-full -mr-6 -mt-6"></div>
                  <p className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">Ticket Promedio</p>
                  <h3 className="text-2xl font-black text-white mb-2">
                    ${paidSales.length > 0 ? (totalRevenue / paidSales.length).toLocaleString('es-MX', { minimumFractionDigits: 2 }) : '0.00'}
                  </h3>
                  <div className="text-[10px] text-blue-400 font-medium">Basado en ventas pagadas</div>
                </div>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                <div className="bg-[#15161a] border border-[#1f2026] rounded-2xl p-5">
                  <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-4">Rendimiento por Agente</h3>
                  <div className="space-y-5">
                    {Object.entries(agentSales).sort((a: any, b: any) => b[1].total - a[1].total).map(([agent, data]: any) => (
                      <div key={agent}>
                        <div className="flex items-center justify-between mb-2">
                          <span className="font-bold text-slate-300 text-sm">{agent}</span>
                          <span className="font-bold text-white text-sm">${data.total.toLocaleString('es-MX', { minimumFractionDigits: 2 })}</span>
                        </div>
                        <div className="w-full bg-[#1f2026] rounded-full h-2 overflow-hidden">
                          <div 
                            className="bg-purple-500 h-full rounded-full"
                            style={{ width: `${Math.max(2, (data.total / totalRevenue) * 100)}%` }}
                          ></div>
                        </div>
                      </div>
                    ))}
                    {Object.keys(agentSales).length === 0 && <div className="text-sm text-slate-500">Sin datos.</div>}
                  </div>
                </div>

                <div className="bg-[#15161a] border border-[#1f2026] rounded-2xl p-5">
                  <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-4">Métodos de Pago</h3>
                  <div className="space-y-3">
                    {Object.entries(
                      paidSales.reduce((acc: any, curr) => {
                        const method = curr.detalles?.paymentMethod || 'Desconocido';
                        acc[method] = (acc[method] || 0) + 1;
                        return acc;
                      }, {})
                    ).sort((a: any, b: any) => b[1] - a[1]).map(([method, count]: any) => (
                      <div key={method} className="flex items-center justify-between p-3 rounded-xl bg-[#1a1b20] border border-[#2a2b32]">
                        <span className="font-bold text-slate-300 text-sm">{method}</span>
                        <span className="bg-[#2a2b32] px-2.5 py-1 rounded-lg text-xs font-bold text-slate-400">
                          {count} {count === 1 ? 'vez' : 'veces'}
                        </span>
                      </div>
                    ))}
                    {paidSales.length === 0 && <div className="text-sm text-slate-500">Sin datos.</div>}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB: GENERADAS */}
          {activeTab === 'generadas' && (
            <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
              <h2 className="text-xl font-bold text-white flex items-center gap-2 mb-6">
                <List className="text-blue-400 w-5 h-5" />
                Todas las Cotizaciones Generadas
              </h2>

              <div className="bg-[#15161a] border border-[#1f2026] rounded-2xl overflow-x-auto overflow-y-hidden">
                <table className="w-full text-left text-sm min-w-[600px]">
                  <thead className="bg-[#1a1b20] text-xs uppercase text-slate-500 font-bold tracking-wider">
                    <tr>
                      <th className="px-4 py-3">Folio / Fecha</th>
                      <th className="px-4 py-3">Cliente</th>
                      <th className="px-4 py-3">Agente</th>
                      <th className="px-4 py-3 text-right">Monto</th>
                      <th className="px-4 py-3 text-center">Estatus</th>
                      <th className="px-4 py-3 text-right">Acción</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#1f2026]">
                    {filteredSales.length === 0 ? (
                      <tr><td colSpan={6} className="px-6 py-12 text-center text-slate-500">No hay cotizaciones en este periodo.</td></tr>
                    ) : (
                      filteredSales.map(sale => {
                        const isPaid = sale.detalles?.isPaid;
                        return (
                          <tr key={sale.id} className="hover:bg-[#1a1b20] transition-colors">
                            <td className="px-4 py-3">
                              <div className="font-bold text-white">{sale.detalles?.folio || 'S/F'}</div>
                              <div className="text-xs text-slate-500">{new Date(sale.created_at).toLocaleDateString('es-MX')}</div>
                            </td>
                            <td className="px-4 py-3 text-slate-300">{sale.detalles?.cliente?.nombre || 'Desconocido'}</td>
                            <td className="px-4 py-3 text-slate-300">{sale.agente || sale.detalles?.vendedor || 'Sin Agente'}</td>
                            <td className="px-4 py-3 text-right font-bold text-white">
                              ${(sale.monto || sale.detalles?.total || 0).toLocaleString('es-MX', { minimumFractionDigits: 2 })}
                            </td>
                            <td className="px-4 py-3 text-center">
                              {isPaid ? (
                                <span className="inline-flex px-2 py-1 rounded-md bg-emerald-500/10 text-emerald-400 text-[10px] font-bold uppercase tracking-wider">Pagada</span>
                              ) : (
                                <span className="inline-flex px-2 py-1 rounded-md bg-amber-500/10 text-amber-400 text-[10px] font-bold uppercase tracking-wider">Pendiente</span>
                              )}
                            </td>
                            <td className="px-4 py-3 text-right">
                              {!isPaid && (
                                <button 
                                  onClick={() => {
                                    setSelectedCot(sale);
                                    setPaymentDate(new Date().toISOString().split('T')[0]);
                                    setPaymentMethod('Transferencia');
                                    setPaymentNotes('');
                                    setShowPaymentModal(true);
                                  }}
                                  className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg bg-blue-500/10 text-blue-400 hover:bg-blue-500/20 text-xs font-bold transition-colors border border-blue-500/20"
                                >
                                  Marcar Pagada
                                </button>
                              )}
                            </td>
                          </tr>
                        );
                      })
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* TAB: COMISIONES (CEO ONLY) */}
          {activeTab === 'comisiones' && (
            <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
              {!isCEO ? (
                <div className="bg-[#15161a] border border-red-500/20 rounded-2xl p-12 text-center">
                  <ShieldAlert className="w-12 h-12 text-red-500/50 mx-auto mb-4" />
                  <h2 className="text-xl font-bold text-white mb-2">Acceso Restringido</h2>
                  <p className="text-slate-400">Esta sección es exclusiva para el CEO.</p>
                </div>
              ) : (
                <>
                  <div className="flex items-center justify-between mb-6">
                    <h2 className="text-xl font-bold text-white flex items-center gap-2">
                      <DollarSign className="text-amber-400 w-5 h-5" />
                      Comisiones por Agente
                    </h2>
                    <button 
                      onClick={() => setShowRuleModal(true)}
                      className="bg-[#1f2026] hover:bg-[#2a2b32] text-white px-4 py-2 rounded-xl flex items-center gap-2 font-bold transition-all border border-[#2a2b32] text-sm"
                    >
                      <Settings className="w-4 h-4" />
                      Reglas de Comisión
                    </button>
                  </div>
                  <div className="bg-[#15161a] border border-[#1f2026] rounded-2xl overflow-x-auto overflow-y-hidden">
                    <table className="w-full text-left text-sm min-w-[600px]">
                      <thead className="bg-[#1a1b20] text-xs uppercase text-slate-500 font-bold tracking-wider">
                        <tr>
                          <th className="px-4 py-3">Agente</th>
                          <th className="px-4 py-3 text-center">Ventas Cerradas</th>
                          <th className="px-4 py-3 text-right">Total Vendido</th>
                          <th className="px-4 py-3 text-right text-amber-400">Comisión Estimada</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-[#1f2026]">
                        {Object.entries(agentSales).length === 0 ? (
                          <tr><td colSpan={4} className="px-6 py-12 text-center text-slate-500">No hay ventas en este periodo.</td></tr>
                        ) : (
                          Object.entries(agentSales).sort((a: any, b: any) => b[1].total - a[1].total).map(([agent, data]: any) => {
                            const commissionAmount = data.commission || 0;
                            const effectiveRate = data.total > 0 ? (commissionAmount / data.total) * 100 : 0;
                            
                            return (
                              <tr key={agent} className="hover:bg-[#1a1b20] transition-colors">
                                <td className="px-4 py-3 font-bold text-white">{agent}</td>
                                <td className="px-4 py-3 text-center text-slate-300">{data.count}</td>
                                <td className="px-4 py-3 text-right text-slate-300">${data.total.toLocaleString('es-MX', { minimumFractionDigits: 2 })}</td>
                                <td className="px-4 py-3 text-right font-black text-amber-400">
                                  ${commissionAmount.toLocaleString('es-MX', { minimumFractionDigits: 2 })}
                                  <span className="text-[10px] text-slate-500 block font-normal">({effectiveRate.toFixed(1)}% prom.)</span>
                                </td>
                              </tr>
                            );
                          })
                        )}
                      </tbody>
                    </table>
                  </div>
                </>
              )}
            </div>
          )}

        </div>
      </div>

      {/* Floating Bottom Navigation */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 bg-[#1a1b20]/90 backdrop-blur-md border border-[#2a2b32] p-2 rounded-2xl flex items-center gap-2 shadow-2xl">
        <button 
          onClick={() => setActiveTab('pagadas')}
          className={`flex flex-col items-center justify-center w-24 h-16 rounded-xl transition-all ${activeTab === 'pagadas' ? 'bg-[#2a2b32] text-white' : 'text-slate-500 hover:text-slate-300 hover:bg-[#1f2026]'}`}
        >
          <CheckSquare className={`w-5 h-5 mb-1 ${activeTab === 'pagadas' ? 'text-emerald-400' : ''}`} />
          <span className="text-[10px] font-bold uppercase tracking-wider">Pagadas</span>
        </button>
        <button 
          onClick={() => setActiveTab('dashboard')}
          className={`flex flex-col items-center justify-center w-24 h-16 rounded-xl transition-all ${activeTab === 'dashboard' ? 'bg-[#2a2b32] text-white' : 'text-slate-500 hover:text-slate-300 hover:bg-[#1f2026]'}`}
        >
          <LayoutDashboard className={`w-5 h-5 mb-1 ${activeTab === 'dashboard' ? 'text-purple-400' : ''}`} />
          <span className="text-[10px] font-bold uppercase tracking-wider">Tablero</span>
        </button>
        <button 
          onClick={() => setActiveTab('generadas')}
          className={`flex flex-col items-center justify-center w-24 h-16 rounded-xl transition-all ${activeTab === 'generadas' ? 'bg-[#2a2b32] text-white' : 'text-slate-500 hover:text-slate-300 hover:bg-[#1f2026]'}`}
        >
          <List className={`w-5 h-5 mb-1 ${activeTab === 'generadas' ? 'text-blue-400' : ''}`} />
          <span className="text-[10px] font-bold uppercase tracking-wider">Generadas</span>
        </button>
        {isCEO && (
          <button 
            onClick={() => setActiveTab('comisiones')}
            className={`flex flex-col items-center justify-center w-24 h-16 rounded-xl transition-all ${activeTab === 'comisiones' ? 'bg-[#2a2b32] text-white' : 'text-slate-500 hover:text-slate-300 hover:bg-[#1f2026]'}`}
          >
            <DollarSign className={`w-5 h-5 mb-1 ${activeTab === 'comisiones' ? 'text-amber-400' : ''}`} />
            <span className="text-[10px] font-bold uppercase tracking-wider">Comisiones</span>
          </button>
        )}
      </div>

      {/* Payment Modal */}
      {showPaymentModal && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-[#15161a] border border-[#2a2b32] rounded-2xl w-full max-w-md p-6 shadow-2xl animate-in fade-in zoom-in duration-200">
            <h3 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
              <CreditCard className="text-blue-400" /> Confirmar Pago
            </h3>
            
            <div className="space-y-4 mb-6">
              <div>
                <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Fecha de Pago</label>
                <input 
                  type="date" 
                  value={paymentDate}
                  onChange={(e) => setPaymentDate(e.target.value)}
                  className="w-full px-4 py-3 bg-[#1a1b20] border border-[#2a2b32] text-white rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Método de Pago</label>
                <select 
                  value={paymentMethod}
                  onChange={(e) => setPaymentMethod(e.target.value)}
                  className="w-full px-4 py-3 bg-[#1a1b20] border border-[#2a2b32] text-white rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                >
                  <option value="Transferencia">Transferencia</option>
                  <option value="Efectivo">Efectivo</option>
                  <option value="Tarjeta de Crédito">Tarjeta de Crédito</option>
                  <option value="Tarjeta de Débito">Tarjeta de Débito</option>
                  <option value="Cheque">Cheque</option>
                  <option value="Otro">Otro</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Notas Especiales</label>
                <textarea 
                  value={paymentNotes}
                  onChange={(e) => setPaymentNotes(e.target.value)}
                  placeholder="Ej. Pago recibido en sucursal..."
                  className="w-full px-4 py-3 bg-[#1a1b20] border border-[#2a2b32] text-white rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none h-24 resize-none"
                />
              </div>
            </div>
            
            <div className="flex gap-3">
              <button 
                onClick={() => {
                  setShowPaymentModal(false);
                  setSelectedCot(null);
                }}
                className="flex-1 py-3 px-4 bg-[#1a1b20] text-slate-300 border border-[#2a2b32] rounded-xl font-bold hover:bg-[#1f2026] transition-colors"
              >
                Cancelar
              </button>
              <button 
                onClick={handleConfirmPayment}
                className="flex-1 py-3 px-4 bg-blue-500 text-white rounded-xl font-bold hover:bg-blue-600 hover:shadow-lg transition-all"
              >
                Confirmar
              </button>
            </div>
          </div>
        </div>
      )}
      {/* Commission Rules Modal */}
      {showRuleModal && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-[#15161a] border border-[#2a2b32] rounded-2xl w-full max-w-2xl p-6 shadow-2xl animate-in fade-in zoom-in duration-200 flex flex-col max-h-[90vh]">
            <div className="flex items-center justify-between mb-6 shrink-0">
              <h3 className="text-xl font-bold text-white flex items-center gap-2">
                <Settings className="text-blue-400" /> Reglas de Comisión
              </h3>
              <button 
                onClick={() => {
                  setEditingRule({ id: Date.now().toString(), name: '', type: 'agent', condition: '', percentage: 0 });
                }}
                className="bg-blue-600 hover:bg-blue-500 text-white px-3 py-1.5 rounded-lg flex items-center gap-2 font-bold transition-all text-sm"
              >
                <Plus className="w-4 h-4" /> Nueva Regla
              </button>
            </div>
            
            <div className="flex-1 overflow-y-auto pr-2 space-y-4">
              {editingRule && (
                <div className="bg-[#1a1b20] border border-blue-500/30 rounded-xl p-4 mb-6">
                  <h4 className="text-sm font-bold text-white mb-4">{commissionRules.find(r => r.id === editingRule.id) ? 'Editar Regla' : 'Nueva Regla'}</h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Nombre de la Regla</label>
                      <input 
                        type="text" 
                        value={editingRule.name}
                        onChange={e => setEditingRule({...editingRule, name: e.target.value})}
                        className="w-full bg-[#15161a] border border-[#2a2b32] rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:border-blue-500"
                        placeholder="Ej. Comisión Valeria"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Tipo de Regla</label>
                      <select 
                        value={editingRule.type}
                        onChange={e => setEditingRule({...editingRule, type: e.target.value as any})}
                        className="w-full bg-[#15161a] border border-[#2a2b32] rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:border-blue-500"
                      >
                        <option value="agent">Por Agente</option>
                        <option value="concept">Por Concepto (Producto)</option>
                        <option value="amount">Por Cantidad (Monto Mínimo)</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Condición</label>
                      <input 
                        type="text" 
                        value={editingRule.condition}
                        onChange={e => setEditingRule({...editingRule, condition: e.target.value})}
                        className="w-full bg-[#15161a] border border-[#2a2b32] rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:border-blue-500"
                        placeholder={editingRule.type === 'amount' ? 'Ej. 10000' : 'Ej. Valeria o Laptop'}
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Porcentaje (%)</label>
                      <input 
                        type="number" 
                        step="0.01"
                        value={editingRule.percentage}
                        onChange={e => setEditingRule({...editingRule, percentage: parseFloat(e.target.value) || 0})}
                        className="w-full bg-[#15161a] border border-[#2a2b32] rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:border-blue-500"
                        placeholder="Ej. 1.4"
                      />
                    </div>
                  </div>
                  <div className="flex justify-end gap-3 mt-4">
                    <button 
                      onClick={() => setEditingRule(null)}
                      className="px-4 py-2 rounded-lg font-bold text-sm text-slate-400 hover:text-white hover:bg-[#2a2b32] transition-colors"
                    >
                      Cancelar
                    </button>
                    <button 
                      onClick={() => {
                        if (commissionRules.find(r => r.id === editingRule.id)) {
                          setCommissionRules(prev => prev.map(r => r.id === editingRule.id ? editingRule : r));
                        } else {
                          setCommissionRules(prev => [...prev, editingRule]);
                        }
                        setEditingRule(null);
                      }}
                      className="px-4 py-2 rounded-lg font-bold text-sm bg-blue-600 hover:bg-blue-500 text-white transition-colors"
                    >
                      Guardar Regla
                    </button>
                  </div>
                </div>
              )}

              <div className="space-y-3">
                {commissionRules.map(rule => (
                  <div key={rule.id} className="bg-[#1a1b20] border border-[#2a2b32] rounded-xl p-4 flex items-center justify-between">
                    <div>
                      <h4 className="font-bold text-white text-sm">{rule.name}</h4>
                      <p className="text-xs text-slate-400 mt-1">
                        {rule.type === 'agent' && `Agente contiene: "${rule.condition}"`}
                        {rule.type === 'concept' && `Concepto contiene: "${rule.condition}"`}
                        {rule.type === 'amount' && `Monto >= $${rule.condition}`}
                      </p>
                    </div>
                    <div className="flex items-center gap-4">
                      <span className="font-black text-amber-400 bg-amber-500/10 px-2 py-1 rounded border border-amber-500/20 text-sm">
                        {rule.percentage}%
                      </span>
                      <button 
                        onClick={() => setEditingRule(rule)}
                        className="text-slate-500 hover:text-blue-400 transition-colors"
                      >
                        Editar
                      </button>
                      <button 
                        onClick={() => setCommissionRules(prev => prev.filter(r => r.id !== rule.id))}
                        className="text-slate-500 hover:text-red-400 transition-colors"
                      >
                        Eliminar
                      </button>
                    </div>
                  </div>
                ))}
                {commissionRules.length === 0 && (
                  <p className="text-center text-slate-500 py-8">No hay reglas de comisión configuradas.</p>
                )}
              </div>
            </div>

            <div className="mt-6 pt-6 border-t border-[#2a2b32] flex justify-end shrink-0">
              <button 
                onClick={() => setShowRuleModal(false)}
                className="px-6 py-2.5 rounded-xl font-bold text-sm bg-[#2a2b32] hover:bg-[#32333a] text-white transition-colors"
              >
                Cerrar
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
