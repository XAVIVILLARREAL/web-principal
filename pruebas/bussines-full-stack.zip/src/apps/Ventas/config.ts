
export const DB_CONFIG = {
  url: import.meta.env.DEV ? "/api/db" : "https://api-datos.xtremediagnostics.com",
  supabaseUrl: "https://api-datos.xtremediagnostics.com",
  supabaseAnonKey: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJyb2xlIjoid2ViX2Fub24iLCJleHAiOjE3NzgwMjYyNTJ9.EuQKKgTEB6qepV3ojfaMbIAxled7Qq-w2n-ph0XTR3A"
};

export const S3_CONFIG = {
  endpoint: 'https://s3.xtremediagnostics.com',
  bucket: 'cotizaciones-xtreme',
  accessKey: 'admin', 
  secretKey: 'Produccion1520-'
};

export const CW_CONFIG = {
  url: import.meta.env.DEV ? "/api/cw" : "https://crm.xtremediagnostics.com",
  token: "EQN2pbRUuBrjdwEmM7PYyjY6"
};
