import React from 'react';
import { images } from '../../Cotizaciones/assets/images_base64';

export interface TicketData {
  id: string;
  fecha: string;
  cliente: {
    name: string;
    email: string;
    phone: string;
    xtreme_id: string;
  };
  titulo: string;
  prioridad: string;
  notas: string;
  tecnico: string;
  isUnderWarranty?: boolean;
}

export const TicketTemplate = React.forwardRef<HTMLDivElement, { data: TicketData }>(
  ({ data }, ref) => {
    return (
      <div ref={ref} className="print-container relative flex flex-col p-12 pt-10 font-sans text-slate-800 bg-white" style={{ width: '816px', height: '1056px', overflow: 'hidden', boxSizing: 'border-box' }}>
        <style>
          {`
            .print-container {
              background-color: white !important;
            }
            @media print {
              .print-container {
                width: 816px !important;
                height: 1056px !important;
              }
            }
          `}
        </style>

        {/* Header */}
        <div className="flex justify-between items-start mb-12 border-b-2 border-slate-100 pb-8">
          <div className="flex flex-col gap-4">
            <img src={images.logo_letras_negrass1} alt="Logo" className="h-16 w-auto object-contain" referrerPolicy="no-referrer" />
            <div>
              <h1 className="text-3xl font-black text-slate-900 tracking-tight uppercase">Ficha de Soporte Técnico</h1>
              <p className="text-slate-500 font-medium">Confirmación de Ticket de Atención</p>
            </div>
          </div>
          <div className="text-right">
            <div className="bg-slate-900 text-white px-6 py-3 rounded-xl inline-block mb-2">
              <span className="text-xs uppercase font-bold tracking-widest block opacity-70">Ticket ID</span>
              <span className="text-2xl font-mono font-bold">#{data.id}</span>
            </div>
            <p className="text-sm text-slate-500 font-medium">Fecha: {data.fecha}</p>
          </div>
        </div>

        {/* Content */}
        <div className="grid grid-cols-2 gap-12 mb-12 relative">
          {data.isUnderWarranty && (
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 rotate-12 opacity-20 pointer-events-none z-0">
              <div className="border-8 border-emerald-600 text-emerald-600 px-8 py-4 rounded-2xl text-5xl font-black uppercase tracking-tighter text-center">
                PAGADO POR<br/>GARANTÍA
              </div>
            </div>
          )}
          <div className="space-y-6 relative z-10">
            <div>
              <h3 className="text-xs uppercase font-bold tracking-widest text-slate-400 mb-2">Información del Cliente</h3>
              <p className="text-xl font-bold text-slate-900">{data.cliente.name}</p>
              <p className="text-slate-600">{data.cliente.email}</p>
              <p className="text-slate-600">{data.cliente.phone}</p>
            </div>
            <div>
              <h3 className="text-xs uppercase font-bold tracking-widest text-slate-400 mb-2">Equipo Relacionado</h3>
              <div className="bg-slate-50 p-4 rounded-xl border border-slate-100">
                <span className="text-xs font-bold text-slate-500 uppercase block mb-1">Xtreme ID</span>
                <span className="text-lg font-mono font-bold text-slate-900">{data.cliente.xtreme_id || 'N/A'}</span>
              </div>
            </div>
          </div>
          <div className="space-y-6">
            <div>
              <h3 className="text-xs uppercase font-bold tracking-widest text-slate-400 mb-2">Detalles del Caso</h3>
              <p className="text-lg font-bold text-slate-900 mb-1">{data.titulo}</p>
              <div className="flex items-center gap-2 mb-4">
                <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider ${
                  data.prioridad === 'Alta' ? 'bg-red-100 text-red-700' :
                  data.prioridad === 'Media' ? 'bg-amber-100 text-amber-700' :
                  'bg-blue-100 text-blue-700'
                }`}>
                  Prioridad {data.prioridad}
                </span>
              </div>
              <div className="bg-slate-50 p-4 rounded-xl border border-slate-100 min-h-[120px]">
                <span className="text-xs font-bold text-slate-500 uppercase block mb-2">Descripción / Notas</span>
                <p className="text-sm text-slate-700 leading-relaxed whitespace-pre-wrap">{data.notas}</p>
              </div>
            </div>
          </div>
        </div>

        {/* Technician & QR */}
        <div className="mt-auto border-t-2 border-slate-100 pt-8 flex justify-between items-end">
          <div className="space-y-6">
            <div>
              <h3 className="text-xs uppercase font-bold tracking-widest text-slate-400 mb-2">Técnico Asignado</h3>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-slate-900 flex items-center justify-center text-white font-bold">
                  {data.tecnico.charAt(0)}
                </div>
                <div>
                  <p className="font-bold text-slate-900">{data.tecnico}</p>
                  <p className="text-xs text-slate-500">Departamento de Soporte</p>
                </div>
              </div>
            </div>
            <div className="max-w-md">
              <p className="text-[10px] text-slate-400 leading-tight italic">
                Este documento confirma la creación de su ticket de soporte. Un técnico revisará su caso y se pondrá en contacto a la brevedad posible. Gracias por su preferencia.
              </p>
            </div>
          </div>
          
          <div className="text-center">
            <div className="bg-white p-2 border border-slate-200 rounded-xl mb-2 inline-block">
              <img src={images.qrterminosycondiciones} alt="QR Terms" className="w-24 h-24 object-contain" referrerPolicy="no-referrer" />
            </div>
            <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Términos y Condiciones</p>
          </div>
        </div>

        {/* Footer Accent */}
        <div className="absolute bottom-0 left-0 right-0 h-2 bg-slate-900"></div>
      </div>
    );
  }
);
