import React, { useState, useEffect } from 'react';
import { createClient } from '@supabase/supabase-js';
import { 
  User, Clock, LogIn, Utensils, Briefcase, LogOut, 
  CheckCircle2, AlertCircle, Loader2, ChevronLeft, ChevronRight,
  LayoutDashboard, Settings, ClipboardList, Timer, Calendar, ShieldCheck,
  TrendingUp, BarChart3, History, Filter, Download, ChevronLast, ChevronFirst,
  MapPin, Navigation, Map
} from 'lucide-react';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, 
  LineChart, Line, Legend, Cell, PieChart, Pie
} from 'recharts';
import { startOfWeek, endOfWeek, addWeeks, subWeeks, format, startOfDay, endOfDay } from 'date-fns';
import { es } from 'date-fns/locale';

// Reemplaza estos valores con los de tu proyecto en Supabase
const SUPABASE_URL = 'https://tu-proyecto.supabase.co';
const SUPABASE_ANON_KEY = 'tu-anon-key-aqui';

const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

interface AsistenciaAppProps {
  username?: string;
  view?: string;
}

interface WorkplaceConfig {
  id?: number;
  lat: number;
  lng: number;
  radius: number;
  enabled: boolean;
}

export default function AsistenciaApp({ username, view }: AsistenciaAppProps) {
  const isCEO = username?.toLowerCase() === 'ceo';
  const [isMobile, setIsMobile] = useState(false);
  const [activeTab, setActiveTab] = useState<'checador' | 'historial' | 'admin'>(view === 'admin' && isCEO ? 'admin' : 'checador');

  useEffect(() => {
    const checkMobile = () => {
      const isMobileDevice = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent) || window.innerWidth < 768;
      setIsMobile(isMobileDevice);
      
      // Security: If mobile and not CEO, force out of admin
      if (isMobileDevice && !isCEO && activeTab === 'admin') {
        setActiveTab('checador');
      }
    };
    
    checkMobile();
    window.addEventListener('resize', checkMobile);
    return () => window.removeEventListener('resize', checkMobile);
  }, [isCEO, activeTab]);

  useEffect(() => {
    // Lock employee for non-CEO in Historial
    if (!isCEO && username) {
      // Map username to the employee IDs used in the system if necessary
      // For now assuming username matches or is close
      const mappedUser = username.startsWith('Checador') ? username : `Checador ${username}`;
      setMyHistorialEmployee(mappedUser);
    }
  }, [isCEO, username]);
  const [adminSubTab, setAdminSubTab] = useState<'monitoreo' | 'analisis' | 'config'>('monitoreo');
  const [currentEmployee, setCurrentEmployee] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [status, setStatus] = useState<{ type: 'success' | 'error', message: string } | null>(null);
  const [currentTime, setCurrentTime] = useState(new Date());

  // Dashboard states
  const [todayRecords, setTodayRecords] = useState<AsistenciaRecord[]>([]);
  const [historicalRecords, setHistoricalRecords] = useState<AsistenciaRecord[]>([]);
  
  // Weekly management
  const [currentWeekStart, setCurrentWeekStart] = useState(startOfWeek(new Date(), { weekStartsOn: 1 }));
  const [selectedEmployeeForAnalysis, setSelectedEmployeeForAnalysis] = useState<string | null>(null);
  
  // Mi Historial states
  const [myHistorialWeekStart, setMyHistorialWeekStart] = useState(startOfWeek(new Date(), { weekStartsOn: 1 }));
  const [myHistorialRecords, setMyHistorialRecords] = useState<AsistenciaRecord[]>([]);
  const [myHistorialEmployee, setMyHistorialEmployee] = useState<string | null>(null);
  
  // Config states
  const [configs, setConfigs] = useState<HorarioConfig[]>([
    { empleado: 'Checador ivan', entrada_programada: '09:00', salida_programada: '19:00', comida_minutos: 60, lat: 0, lng: 0, radius: 100, gps_enabled: false },
    { empleado: 'Checador Valeria', entrada_programada: '08:00', salida_programada: '17:00', comida_minutos: 60, lat: 0, lng: 0, radius: 100, gps_enabled: false }
  ]);

  useEffect(() => {
    if (view === 'admin' && isCEO) {
      setActiveTab('admin');
    }
  }, [view, isCEO]);

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    if (activeTab === 'admin') {
      fetchTodayRecords();
      fetchConfigs();
      if (adminSubTab === 'analisis') {
        fetchHistoricalRecords();
      }
    } else if (activeTab === 'historial') {
      fetchMyHistoricalRecords();
    }
  }, [activeTab, adminSubTab, currentWeekStart, myHistorialWeekStart, myHistorialEmployee]);

  const fetchMyHistoricalRecords = async () => {
    if (!myHistorialEmployee) {
      setMyHistorialRecords([]);
      return;
    }
    setLoading(true);
    try {
      const start = format(myHistorialWeekStart, 'yyyy-MM-dd');
      const end = format(endOfWeek(myHistorialWeekStart, { weekStartsOn: 1 }), 'yyyy-MM-dd');
      
      const { data, error } = await supabase
        .from('asistencia')
        .select('*')
        .eq('empleado', myHistorialEmployee)
        .gte('fecha', start)
        .lte('fecha', end)
        .order('fecha', { ascending: true });
      
      if (error) throw error;
      setMyHistorialRecords(data || []);
    } catch (error) {
      console.error(error);
      showStatus('error', 'Error al cargar historial');
    } finally {
      setLoading(false);
    }
  };

  const fetchHistoricalRecords = async () => {
    setLoading(true);
    try {
      const start = format(currentWeekStart, 'yyyy-MM-dd');
      const end = format(endOfWeek(currentWeekStart, { weekStartsOn: 1 }), 'yyyy-MM-dd');
      
      const { data, error } = await supabase
        .from('asistencia')
        .select('*')
        .gte('fecha', start)
        .lte('fecha', end)
        .order('fecha', { ascending: true });
      
      if (error) throw error;
      setHistoricalRecords(data || []);
    } catch (error) {
      console.error(error);
      showStatus('error', 'Error al cargar historial');
    } finally {
      setLoading(false);
    }
  };

  const fetchTodayRecords = async () => {
    setLoading(true);
    try {
      const today = new Date().toISOString().split('T')[0];
      const { data, error } = await supabase
        .from('asistencia')
        .select('*')
        .eq('fecha', today);
      
      if (error) throw error;
      setTodayRecords(data || []);
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const fetchConfigs = async () => {
    try {
      const { data, error } = await supabase
        .from('configuracion_asistencia')
        .select('*');
      
      if (error) {
        console.warn("Tabla de configuración no encontrada, usando valores por defecto");
        return;
      }
      if (data && data.length > 0) setConfigs(data);
    } catch (error) {
      console.error(error);
    }
  };

  const saveConfig = async (config: HorarioConfig) => {
    setLoading(true);
    try {
      const { error } = await supabase
        .from('configuracion_asistencia')
        .upsert([config], { onConflict: 'empleado' });
      
      if (error) throw error;
      showStatus('success', 'Configuración guardada');
      fetchConfigs();
    } catch (error: any) {
      showStatus('error', 'Error al guardar: ' + error.message);
    } finally {
      setLoading(false);
    }
  };

  const showStatus = (type: 'success' | 'error', message: string) => {
    setStatus({ type, message });
    setTimeout(() => setStatus(null), 5000);
  };

  const handleAction = async (action: string) => {
    if (!currentEmployee) return;
    
    setLoading(true);
    try {
      const now = new Date();
      const today = now.toISOString().split('T')[0];
      const timestamp = now.toISOString();

      // GPS Check for Entrada
      let lat = null;
      let lng = null;

      const employeeConfig = configs.find(c => c.empleado === currentEmployee);

      if (action === "Entrada" && employeeConfig?.gps_enabled) {
        try {
          const position = await new Promise<GeolocationPosition>((resolve, reject) => {
            navigator.geolocation.getCurrentPosition(resolve, reject, {
              enableHighAccuracy: true,
              timeout: 10000,
              maximumAge: 0
            });
          });
          
          lat = position.coords.latitude;
          lng = position.coords.longitude;

          const distance = getDistance(lat, lng, employeeConfig.lat || 0, employeeConfig.lng || 0);
          
          if (distance > (employeeConfig.radius || 100)) {
            showStatus('error', `Estás fuera del rango permitido (${Math.round(distance)}m). Debes estar en el trabajo.`);
            setLoading(false);
            return;
          }
        } catch (geoError) {
          showStatus('error', 'No se pudo obtener tu ubicación GPS. Activa el GPS para registrar entrada.');
          setLoading(false);
          return;
        }
      }

      const actionMap: Record<string, keyof AsistenciaRecord> = {
        "Entrada": "entrada",
        "Salir a comer": "salida_comida",
        "Reconexion de comida": "regreso_comida",
        "Asuntos personales desconexion": "salida_personal",
        "Reconexion asuntos personales": "regreso_personal",
        "Salida": "salida"
      };

      const column = actionMap[action];

      const { data: existing, error: fetchError } = await supabase
        .from('asistencia')
        .select('*')
        .eq('empleado', currentEmployee)
        .eq('fecha', today)
        .maybeSingle();

      if (fetchError) throw fetchError;

      if (action === "Entrada") {
        if (existing) {
          showStatus('error', 'Ya registraste entrada hoy');
          return;
        }

        const { error: insertError } = await supabase
          .from('asistencia')
          .insert([{ 
            empleado: currentEmployee, 
            fecha: today, 
            entrada: timestamp,
            lat_entrada: lat,
            lng_entrada: lng
          }]);
        
        if (insertError) throw insertError;
        showStatus('success', 'Entrada registrada exitosamente');
      } else {
        if (!existing) {
          showStatus('error', 'No has registrado entrada hoy');
          return;
        }

        if (action !== "Salida" && existing[column]) {
          showStatus('error', `Ya registraste '${action}' hoy`);
          return;
        }

        const { error: updateError } = await supabase
          .from('asistencia')
          .update({ [column]: timestamp })
          .eq('id', existing.id);

        if (updateError) throw updateError;
        showStatus('success', action + " registrado exitosamente");
      }
    } catch (error: any) {
      console.error(error);
      showStatus('error', 'Error: ' + (error.message || 'Error desconocido'));
    } finally {
      setLoading(false);
    }
  };

  const getDistance = (lat1: number, lon1: number, lat2: number, lon2: number) => {
    const R = 6371e3; // metres
    const φ1 = lat1 * Math.PI/180;
    const φ2 = lat2 * Math.PI/180;
    const Δφ = (lat2-lat1) * Math.PI/180;
    const Δλ = (lon2-lon1) * Math.PI/180;

    const a = Math.sin(Δφ/2) * Math.sin(Δφ/2) +
              Math.cos(φ1) * Math.cos(φ2) *
              Math.sin(Δλ/2) * Math.sin(Δλ/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));

    return R * c; // in metres
  };

  const formatTime = (isoString: string | null) => {
    if (!isoString) return '--:--';
    return new Date(isoString).toLocaleTimeString('es-MX', { hour: '2-digit', minute: '2-digit', hour12: false });
  };

  // Helper calculation functions
  const getDiffInHours = (start: string | null, end: string | null) => {
    if (!start || !end) return 0;
    const diff = (new Date(end).getTime() - new Date(start).getTime()) / (1000 * 60 * 60);
    return Math.max(0, diff);
  };

  const calculateRecordStats = (record: AsistenciaRecord, config?: HorarioConfig) => {
    if (!record.entrada || !record.salida) return { worked: 0, missing: 0, expected: 0 };

    // Total worked time
    const totalTime = getDiffInHours(record.entrada, record.salida);
    
    // Break times
    const lunchTime = getDiffInHours(record.salida_comida, record.regreso_comida);
    const personalTime = getDiffInHours(record.salida_personal, record.regreso_personal);
    
    const actualWorked = totalTime - lunchTime - personalTime;

    // Expected time from config
    let expected = 8; // Default
    if (config) {
      const [hEnt, mEnt] = config.entrada_programada.split(':').map(Number);
      const [hSal, mSal] = config.salida_programada.split(':').map(Number);
      expected = (hSal + mSal/60) - (hEnt + mEnt/60) - (config.comida_minutos / 60);
    }

    const missing = Math.max(0, expected - actualWorked);

    return {
      worked: actualWorked,
      missing: missing,
      expected: expected
    };
  };

  const getAnalysisData = () => {
    const dataByDate: Record<string, any> = {};
    
    historicalRecords.forEach(record => {
      const config = configs.find(c => c.empleado === record.empleado);
      const stats = calculateRecordStats(record, config);
      
      if (!dataByDate[record.fecha]) {
        dataByDate[record.fecha] = { fecha: record.fecha, worked: 0, missing: 0, count: 0 };
      }
      
      dataByDate[record.fecha].worked += stats.worked;
      dataByDate[record.fecha].missing += stats.missing;
      dataByDate[record.fecha].count += 1;
    });

    return Object.values(dataByDate).map(d => ({
      ...d,
      worked: Number((d.worked / d.count).toFixed(2)),
      missing: Number((d.missing / d.count).toFixed(2))
    }));
  };

  const getEmployeeAnalysis = () => {
    const empData: Record<string, any> = {};
    
    historicalRecords.forEach(record => {
      const config = configs.find(c => c.empleado === record.empleado);
      const stats = calculateRecordStats(record, config);
      const name = record.empleado.split(' ')[1];
      
      if (!empData[name]) {
        empData[name] = { name, totalWorked: 0, totalMissing: 0, days: 0 };
      }
      
      empData[name].totalWorked += stats.worked;
      empData[name].totalMissing += stats.missing;
      empData[name].days += 1;
    });

    return Object.values(empData).map(e => ({
      ...e,
      avgWorked: Number((e.totalWorked / e.days).toFixed(2)),
      avgMissing: Number((e.totalMissing / e.days).toFixed(2))
    }));
  };

  return (
    <div className="h-full w-full bg-[#0f172a] flex flex-col font-sans text-slate-200 overflow-hidden relative">
      {/* Background decoration */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,_rgba(30,58,138,0.1),_transparent_70%)] pointer-events-none" />
      
      {/* Navigation Header */}
      <div className="flex flex-col sm:flex-row items-center justify-between px-6 py-4 bg-[#1e293b]/80 backdrop-blur-md border-b border-slate-700/50 shrink-0 z-20 gap-4">
        <div className="flex items-center gap-3 w-full sm:w-auto">
          <div className="p-2 bg-indigo-600 rounded-lg shadow-lg shadow-indigo-500/20">
            <Clock className="text-white" size={20} />
          </div>
          <div>
            <h1 className="text-sm font-black uppercase tracking-[0.2em] text-white">Xtreme Asistencia</h1>
            <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">System v2.0</p>
          </div>
        </div>

        <div className="flex bg-[#0f172a] p-1 rounded-xl border border-slate-700/50 w-full sm:w-auto overflow-x-auto no-scrollbar">
          <button 
            onClick={() => setActiveTab('checador')}
            className={`flex-1 sm:flex-none px-4 py-2 rounded-lg flex items-center justify-center gap-2 transition-all text-[10px] font-black uppercase tracking-widest whitespace-nowrap ${activeTab === 'checador' ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-500/20' : 'text-slate-500 hover:text-slate-300'}`}
          >
            <Timer size={14} /> Checador
          </button>
          <button 
            onClick={() => setActiveTab('historial')}
            className={`flex-1 sm:flex-none px-4 py-2 rounded-lg flex items-center justify-center gap-2 transition-all text-[10px] font-black uppercase tracking-widest whitespace-nowrap ${activeTab === 'historial' ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-500/20' : 'text-slate-500 hover:text-slate-300'}`}
          >
            <History size={14} /> Mi Historial
          </button>
          {isCEO && (!isMobile || isCEO) && (
            <button 
              onClick={() => setActiveTab('admin')}
              className={`flex-1 sm:flex-none px-4 py-2 rounded-lg flex items-center justify-center gap-2 transition-all text-[10px] font-black uppercase tracking-widest whitespace-nowrap ${activeTab === 'admin' ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-500/20' : 'text-slate-500 hover:text-slate-300'}`}
            >
              <ShieldCheck size={14} /> Admin Panel
            </button>
          )}
        </div>
      </div>

      {/* Main Content Area - SCROLLABLE */}
      <div className="flex-1 overflow-y-auto relative z-10 p-4 sm:p-8 no-scrollbar scroll-smooth">
        
        {activeTab === 'checador' && (
          <div className="max-w-md mx-auto animate-in fade-in slide-in-from-bottom-4 duration-500">
            <div className="bg-[#1e293b] rounded-[2.5rem] shadow-2xl border border-slate-700/50 overflow-hidden">
              {/* Clock Section */}
              <div className="p-10 text-center bg-gradient-to-b from-slate-800 to-transparent">
                <div className="text-6xl font-mono font-black tracking-tighter text-indigo-400 mb-2 drop-shadow-[0_0_15px_rgba(129,140,248,0.3)]">
                  {currentTime.toLocaleTimeString('es-MX', { hour12: false })}
                </div>
                <div className="text-xs font-bold text-slate-400 uppercase tracking-[0.3em] mb-8">
                  {currentTime.toLocaleDateString('es-MX', { weekday: 'long', day: 'numeric', month: 'long' })}
                </div>

                {/* Employee Selection */}
                <div className="grid grid-cols-2 gap-4">
                  {[
                    { id: 'Checador ivan', name: 'Iván' },
                    { id: 'Checador Valeria', name: 'Valeria' }
                  ].map((emp) => (
                    <button 
                      key={emp.id}
                      onClick={() => setCurrentEmployee(emp.id)}
                      className={`
                        relative group py-6 px-4 rounded-3xl border-2 transition-all duration-300 flex flex-col items-center gap-3
                        ${currentEmployee === emp.id 
                          ? 'border-indigo-500 bg-indigo-500/10 text-white shadow-[0_0_30px_rgba(99,102,241,0.2)]' 
                          : 'border-slate-700/50 bg-slate-800/50 text-slate-500 hover:border-slate-600'}
                      `}
                    >
                      <div className={`
                        p-4 rounded-2xl transition-all duration-300
                        ${currentEmployee === emp.id ? 'bg-indigo-500 text-white' : 'bg-slate-700 text-slate-500 group-hover:bg-slate-600'}
                      `}>
                        <User size={24} />
                      </div>
                      <span className="font-black text-xs uppercase tracking-widest">{emp.name}</span>
                      {currentEmployee === emp.id && (
                        <div className="absolute -top-2 -right-2 bg-indigo-500 text-white p-1 rounded-full shadow-lg">
                          <CheckCircle2 size={14} />
                        </div>
                      )}
                    </button>
                  ))}
                </div>
              </div>

              {/* Actions Section */}
              <div className="p-8 space-y-6">
                {status && (
                  <div className={`
                    p-4 rounded-2xl flex items-start gap-3 animate-in fade-in zoom-in duration-300
                    ${status.type === 'success' ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' : 'bg-rose-500/10 text-rose-400 border border-rose-500/20'}
                  `}>
                    {status.type === 'success' ? <CheckCircle2 className="shrink-0" size={20} /> : <AlertCircle className="shrink-0" size={20} />}
                    <p className="text-xs font-bold uppercase tracking-wider leading-relaxed">{status.message}</p>
                  </div>
                )}

                <div className={`grid grid-cols-1 gap-4 transition-all duration-500 ${!currentEmployee ? 'opacity-20 pointer-events-none grayscale' : 'opacity-100'}`}>
                  <ActionButton 
                    onClick={() => handleAction('Entrada')} 
                    icon={<LogIn size={20} />} 
                    label="Registrar Entrada" 
                    color="bg-indigo-600 hover:bg-indigo-500 shadow-indigo-500/20" 
                  />
                  
                  <div className="grid grid-cols-2 gap-4">
                    <ActionButton 
                      onClick={() => handleAction('Salir a comer')} 
                      icon={<Utensils size={18} />} 
                      label="Comida" 
                      color="bg-slate-700 hover:bg-slate-600" 
                    />
                    <ActionButton 
                      onClick={() => handleAction('Reconexion de comida')} 
                      icon={<CheckCircle2 size={18} />} 
                      label="Regreso" 
                      color="bg-emerald-600 hover:bg-emerald-500" 
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <ActionButton 
                      onClick={() => handleAction('Asuntos personales desconexion')} 
                      icon={<Briefcase size={18} />} 
                      label="Personal" 
                      color="bg-slate-700 hover:bg-slate-600" 
                    />
                    <ActionButton 
                      onClick={() => handleAction('Reconexion asuntos personales')} 
                      icon={<CheckCircle2 size={18} />} 
                      label="Regreso" 
                      color="bg-emerald-600 hover:bg-emerald-500" 
                    />
                  </div>

                  <ActionButton 
                    onClick={() => handleAction('Salida')} 
                    icon={<LogOut size={20} />} 
                    label="Registrar Salida" 
                    color="bg-rose-600 hover:bg-rose-500 shadow-rose-500/20" 
                  />
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'historial' && (
          <div className="max-w-4xl mx-auto animate-in fade-in slide-in-from-bottom-4 duration-500 space-y-8">
            <div className="flex flex-col sm:flex-row items-center justify-between gap-4 bg-[#1e293b] p-6 rounded-[2rem] border border-slate-700/50 shadow-2xl">
              <div className="flex items-center gap-4">
                <div className="p-3 bg-indigo-500/10 rounded-xl">
                  <History className="text-indigo-400" size={24} />
                </div>
                <div>
                  <h2 className="text-lg font-black uppercase tracking-widest text-white">Mi Historial</h2>
                  <p className="text-xs text-slate-400 font-bold uppercase tracking-widest">Análisis de Horarios</p>
                </div>
              </div>
              
              <div className="flex flex-col sm:flex-row items-center gap-4">
                {isCEO ? (
                  <select 
                    value={myHistorialEmployee || ''} 
                    onChange={(e) => setMyHistorialEmployee(e.target.value)}
                    className="bg-[#0f172a] border border-slate-700 text-white text-xs font-bold rounded-lg px-4 py-2 focus:outline-none focus:border-indigo-500 uppercase tracking-widest"
                  >
                    <option value="">Seleccionar Empleado</option>
                    <option value="Checador ivan">Iván</option>
                    <option value="Checador Valeria">Valeria</option>
                  </select>
                ) : (
                  <div className="bg-[#0f172a] border border-slate-700 text-indigo-400 text-[10px] font-black rounded-lg px-4 py-2 uppercase tracking-widest">
                    {myHistorialEmployee?.split(' ')[1] || username}
                  </div>
                )}

                <div className="flex items-center gap-2 bg-[#0f172a] p-1 rounded-xl border border-slate-700/50">
                  <button 
                    onClick={() => setMyHistorialWeekStart(subWeeks(myHistorialWeekStart, 1))}
                    className="p-2 hover:bg-slate-800 rounded-lg transition-colors text-slate-400 hover:text-white"
                  >
                    <ChevronLeft size={16} />
                  </button>
                  <span className="text-[10px] font-black uppercase tracking-widest text-white px-2">
                    {format(myHistorialWeekStart, "d MMM", { locale: es })} - {format(endOfWeek(myHistorialWeekStart, { weekStartsOn: 1 }), "d MMM", { locale: es })}
                  </span>
                  <button 
                    onClick={() => setMyHistorialWeekStart(addWeeks(myHistorialWeekStart, 1))}
                    className="p-2 hover:bg-slate-800 rounded-lg transition-colors text-slate-400 hover:text-white"
                  >
                    <ChevronRight size={16} />
                  </button>
                </div>
              </div>
            </div>

            {myHistorialEmployee ? (
              <div className="space-y-8">
                {/* Summary Cards for Employee */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
                  <div className="bg-[#1e293b] p-6 rounded-3xl border border-slate-700/50 shadow-xl">
                    <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-2">Total Horas</p>
                    <div className="text-3xl font-black text-white">
                      {myHistorialRecords.reduce((acc, r) => acc + calculateRecordStats(r, configs.find(c => c.empleado === r.empleado)).worked, 0).toFixed(1)}h
                    </div>
                  </div>
                  <div className="bg-[#1e293b] p-6 rounded-3xl border border-slate-700/50 shadow-xl">
                    <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-2">Promedio Diario</p>
                    <div className="text-3xl font-black text-emerald-400">
                      {(myHistorialRecords.reduce((acc, r) => acc + calculateRecordStats(r, configs.find(c => c.empleado === r.empleado)).worked, 0) / (myHistorialRecords.length || 1)).toFixed(1)}h
                    </div>
                  </div>
                  <div className="bg-[#1e293b] p-6 rounded-3xl border border-slate-700/50 shadow-xl">
                    <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-2">Días Registrados</p>
                    <div className="text-3xl font-black text-indigo-400">{myHistorialRecords.length}</div>
                  </div>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                  <div className="bg-[#1e293b] p-4 sm:p-8 rounded-[2.5rem] border border-slate-700/50 shadow-2xl">
                    <div className="flex items-center gap-2 mb-8">
                      <BarChart3 className="text-indigo-400" size={18} />
                      <h3 className="text-sm font-black uppercase tracking-widest text-white">Horas Trabajadas vs Faltantes</h3>
                    </div>
                    <div className="h-[300px] w-full">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart data={
                          myHistorialRecords.map(r => {
                            const config = configs.find(c => c.empleado === r.empleado);
                            const stats = calculateRecordStats(r, config);
                            return { fecha: r.fecha, worked: stats.worked, missing: stats.missing };
                          })
                        }>
                          <CartesianGrid strokeDasharray="3 3" stroke="#334155" vertical={false} />
                          <XAxis 
                            dataKey="fecha" 
                            stroke="#64748b" 
                            fontSize={10} 
                            tickFormatter={(val) => format(new Date(val + 'T12:00:00'), 'EEE d', { locale: es })}
                          />
                          <YAxis stroke="#64748b" fontSize={10} />
                          <Tooltip 
                            contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155', borderRadius: '12px' }}
                            itemStyle={{ fontSize: '12px', fontWeight: 'bold' }}
                            labelFormatter={(val) => format(new Date(val + 'T12:00:00'), "EEEE d 'de' MMMM", { locale: es })}
                          />
                          <Legend wrapperStyle={{ fontSize: '10px', fontWeight: 'black', textTransform: 'uppercase', paddingTop: '20px' }} />
                          <Bar dataKey="worked" name="Horas Trabajadas" fill="#6366f1" radius={[4, 4, 0, 0]} />
                          <Bar dataKey="missing" name="Horas Faltantes" fill="#f43f5e" radius={[4, 4, 0, 0]} />
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                  </div>

                  <div className="bg-[#1e293b] p-4 sm:p-8 rounded-[2.5rem] border border-slate-700/50 shadow-2xl">
                    <div className="flex items-center gap-2 mb-8">
                      <TrendingUp className="text-emerald-400" size={18} />
                      <h3 className="text-sm font-black uppercase tracking-widest text-white">Tendencia de Puntualidad</h3>
                    </div>
                    <div className="h-[300px] w-full">
                      <ResponsiveContainer width="100%" height="100%">
                        <LineChart data={
                          myHistorialRecords.map(r => {
                            const config = configs.find(c => c.empleado === r.empleado);
                            const stats = calculateRecordStats(r, config);
                            return { 
                              fecha: r.fecha, 
                              worked: stats.worked,
                              // Calculate delay in minutes from expected entry
                              delay: r.entrada && config ? (() => {
                                const [hExp, mExp] = config.entrada_programada.split(':').map(Number);
                                const entry = new Date(r.entrada);
                                const hEnt = entry.getHours();
                                const mEnt = entry.getMinutes();
                                const diff = (hEnt * 60 + mEnt) - (hExp * 60 + mExp);
                                return Math.max(0, diff);
                              })() : 0
                            };
                          })
                        }>
                          <CartesianGrid strokeDasharray="3 3" stroke="#334155" vertical={false} />
                          <XAxis 
                            dataKey="fecha" 
                            stroke="#64748b" 
                            fontSize={10} 
                            tickFormatter={(val) => format(new Date(val + 'T12:00:00'), 'EEE d', { locale: es })}
                          />
                          <YAxis stroke="#64748b" fontSize={10} />
                          <Tooltip 
                            contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155', borderRadius: '12px' }}
                            itemStyle={{ fontSize: '12px', fontWeight: 'bold' }}
                            labelFormatter={(val) => format(new Date(val + 'T12:00:00'), "EEEE d 'de' MMMM", { locale: es })}
                          />
                          <Legend wrapperStyle={{ fontSize: '10px', fontWeight: 'black', textTransform: 'uppercase', paddingTop: '20px' }} />
                          <Line type="monotone" dataKey="delay" name="Minutos de Retraso" stroke="#f43f5e" strokeWidth={3} dot={{ r: 4, fill: '#f43f5e' }} />
                          <Line type="monotone" dataKey="worked" name="Horas Reales" stroke="#10b981" strokeWidth={3} dot={{ r: 4, fill: '#10b981' }} />
                        </LineChart>
                      </ResponsiveContainer>
                    </div>
                  </div>
                </div>

                {/* Detailed Table for Personal History */}
                <div className="bg-[#1e293b] rounded-[2.5rem] border border-slate-700/50 shadow-2xl overflow-hidden">
                  <div className="p-8 border-b border-slate-700/50">
                    <h2 className="text-lg font-black uppercase tracking-widest text-white">Detalle de Mis Registros</h2>
                  </div>
                  <div className="overflow-x-auto">
                    <table className="w-full text-left border-collapse">
                      <thead>
                        <tr className="bg-slate-800/50 text-[10px] font-black text-slate-500 uppercase tracking-widest">
                          <th className="px-8 py-4">Fecha</th>
                          <th className="px-8 py-4">Entrada</th>
                          <th className="px-8 py-4">Salida</th>
                          <th className="px-8 py-4 text-right">Trabajadas</th>
                          <th className="px-8 py-4 text-right">Faltantes</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-700/30">
                        {myHistorialRecords.map(record => {
                          const config = configs.find(c => c.empleado === record.empleado);
                          const stats = calculateRecordStats(record, config);
                          return (
                            <tr key={record.id} className="hover:bg-slate-800/30 transition-colors">
                              <td className="px-8 py-4 text-xs font-bold text-slate-400">{record.fecha}</td>
                              <td className="px-8 py-4 text-xs font-mono text-slate-300">{formatTime(record.entrada)}</td>
                              <td className="px-8 py-4 text-xs font-mono text-slate-300">{formatTime(record.salida)}</td>
                              <td className="px-8 py-4 text-right">
                                <span className="px-2 py-1 rounded-lg bg-emerald-500/10 text-emerald-400 text-[10px] font-black">
                                  {stats.worked.toFixed(2)}h
                                </span>
                              </td>
                              <td className="px-8 py-4 text-right">
                                <span className={`px-2 py-1 rounded-lg text-[10px] font-black ${stats.missing > 0 ? 'bg-rose-500/10 text-rose-400' : 'bg-slate-500/10 text-slate-500'}`}>
                                  {stats.missing.toFixed(2)}h
                                </span>
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            ) : (
              <div className="bg-[#1e293b] p-12 rounded-[2.5rem] border border-slate-700/50 shadow-2xl text-center">
                <User size={48} className="text-slate-600 mx-auto mb-4" />
                <p className="text-sm font-bold text-slate-400 uppercase tracking-widest">Selecciona un empleado para ver su historial</p>
              </div>
            )}
          </div>
        )}

        {activeTab === 'admin' && isCEO && (
          <div className="max-w-6xl mx-auto space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
            {/* Admin Sub-Tabs */}
            <div className="flex items-center gap-2 mb-2 overflow-x-auto no-scrollbar pb-2">
              <button 
                onClick={() => setAdminSubTab('monitoreo')}
                className={`flex items-center gap-2 px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all whitespace-nowrap ${adminSubTab === 'monitoreo' ? 'bg-indigo-500/20 text-indigo-400 border border-indigo-500/30' : 'text-slate-500 hover:text-slate-300'}`}
              >
                <LayoutDashboard size={14} /> Monitoreo
              </button>
              <button 
                onClick={() => setAdminSubTab('analisis')}
                className={`flex items-center gap-2 px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all whitespace-nowrap ${adminSubTab === 'analisis' ? 'bg-indigo-500/20 text-indigo-400 border border-indigo-500/30' : 'text-slate-500 hover:text-slate-300'}`}
              >
                <TrendingUp size={14} /> Análisis
              </button>
              <button 
                onClick={() => setAdminSubTab('config')}
                className={`flex items-center gap-2 px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all whitespace-nowrap ${adminSubTab === 'config' ? 'bg-indigo-500/20 text-indigo-400 border border-indigo-500/30' : 'text-slate-500 hover:text-slate-300'}`}
              >
                <Settings size={14} /> Config
              </button>
            </div>

            {adminSubTab === 'monitoreo' && (
              <>
                {/* Admin Header Stats */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="bg-[#1e293b] p-8 rounded-[2rem] border border-slate-700/50 shadow-xl">
                    <div className="flex items-center justify-between mb-4">
                      <div className="p-3 bg-indigo-500/10 rounded-2xl text-indigo-400">
                        <User size={24} />
                      </div>
                      <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Personal Activo</span>
                    </div>
                    <div className="text-4xl font-black text-white">{todayRecords.length}</div>
                    <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest mt-2">Registrados hoy</p>
                  </div>
                  <div className="bg-[#1e293b] p-8 rounded-[2rem] border border-slate-700/50 shadow-xl">
                    <div className="flex items-center justify-between mb-4">
                      <div className="p-3 bg-emerald-500/10 rounded-2xl text-emerald-400">
                        <CheckCircle2 size={24} />
                      </div>
                      <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Finalizados</span>
                    </div>
                    <div className="text-4xl font-black text-white">{todayRecords.filter(r => r.salida).length}</div>
                    <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest mt-2">Turnos cerrados</p>
                  </div>
                  <div className="bg-[#1e293b] p-8 rounded-[2rem] border border-slate-700/50 shadow-xl">
                    <div className="flex items-center justify-between mb-4">
                      <div className="p-3 bg-amber-500/10 rounded-2xl text-amber-400">
                        <Utensils size={24} />
                      </div>
                      <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest">En Comida</span>
                    </div>
                    <div className="text-4xl font-black text-white">{todayRecords.filter(r => r.salida_comida && !r.regreso_comida).length}</div>
                    <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest mt-2">Personal ausente</p>
                  </div>
                </div>

                {/* Real-time Dashboard */}
                <div className="bg-[#1e293b] rounded-[2.5rem] border border-slate-700/50 shadow-2xl overflow-hidden">
                  <div className="p-8 border-b border-slate-700/50 flex items-center justify-between">
                    <h2 className="text-lg font-black uppercase tracking-widest text-white flex items-center gap-3">
                      <LayoutDashboard className="text-indigo-400" /> Monitoreo en Vivo
                    </h2>
                    <button onClick={fetchTodayRecords} className="p-2 hover:bg-slate-700 rounded-xl transition-colors text-slate-400">
                      <Calendar size={20} />
                    </button>
                  </div>
                  <div className="p-8">
                    <div className="space-y-4">
                      {['Checador ivan', 'Checador Valeria'].map(empId => {
                        const record = todayRecords.find(r => r.empleado === empId);
                        const name = empId.split(' ')[1];
                        return (
                          <div key={empId} className="bg-slate-800/50 rounded-[1.5rem] p-6 border border-slate-700/30 flex flex-col sm:flex-row sm:items-center justify-between gap-6">
                            <div className="flex items-center gap-4">
                              <div className="w-14 h-14 rounded-2xl bg-indigo-500/10 text-indigo-400 flex items-center justify-center text-xl font-black border border-indigo-500/20">
                                {name[0]}
                              </div>
                              <div>
                                <div className="flex items-center gap-2">
                                  <h3 className="font-black text-white uppercase tracking-wider">{name}</h3>
                                  {record?.lat_entrada && (
                                    <div className="flex items-center gap-1 px-2 py-0.5 rounded-full bg-indigo-500/10 border border-indigo-500/20">
                                      <MapPin size={8} className="text-indigo-400" />
                                      <span className="text-[8px] font-black text-indigo-400 uppercase tracking-widest">GPS OK</span>
                                    </div>
                                  )}
                                </div>
                                <div className="flex items-center gap-2 mt-1">
                                  <span className={`w-2 h-2 rounded-full ${record?.entrada ? (record.salida ? 'bg-slate-500' : 'bg-emerald-500 animate-pulse') : 'bg-rose-500'}`} />
                                  <span className="text-[10px] font-black uppercase tracking-widest text-slate-400">
                                    {record?.entrada ? (record.salida ? 'Turno Finalizado' : 'En Turno') : 'No ha llegado'}
                                  </span>
                                </div>
                              </div>
                            </div>

                            <div className="grid grid-cols-3 gap-4">
                              <div className="text-center">
                                <span className="block text-[8px] font-black text-slate-500 uppercase tracking-widest mb-1">Entrada</span>
                                <span className="text-sm font-mono font-bold text-white">{formatTime(record?.entrada || null)}</span>
                              </div>
                              <div className="text-center">
                                <span className="block text-[8px] font-black text-slate-500 uppercase tracking-widest mb-1">Comida</span>
                                <span className="text-sm font-mono font-bold text-white">{record?.salida_comida ? 'Salió' : '--:--'}</span>
                              </div>
                              <div className="text-center">
                                <span className="block text-[8px] font-black text-slate-500 uppercase tracking-widest mb-1">Salida</span>
                                <span className="text-sm font-mono font-bold text-white">{formatTime(record?.salida || null)}</span>
                              </div>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </div>
              </>
            )}

            {adminSubTab === 'analisis' && (
              <div className="space-y-8">
                {/* Weekly Selector */}
                <div className="bg-[#1e293b] p-6 rounded-3xl border border-slate-700/50 shadow-xl flex flex-wrap items-center justify-between gap-6">
                  <div className="flex items-center gap-4">
                    <div className="p-3 bg-indigo-500/10 rounded-2xl text-indigo-400">
                      <Calendar size={24} />
                    </div>
                    <div>
                      <h3 className="text-sm font-black uppercase tracking-widest text-white">Periodo de Pago Semanal</h3>
                      <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">
                        {format(currentWeekStart, "d 'de' MMMM", { locale: es })} - {format(endOfWeek(currentWeekStart, { weekStartsOn: 1 }), "d 'de' MMMM, yyyy", { locale: es })}
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-2 bg-[#0f172a] p-1.5 rounded-2xl border border-slate-700/50">
                    <button 
                      onClick={() => setCurrentWeekStart(prev => subWeeks(prev, 1))}
                      className="p-2.5 hover:bg-slate-800 rounded-xl transition-all text-slate-400 hover:text-white"
                      title="Semana Anterior"
                    >
                      <ChevronLeft size={20} />
                    </button>
                    <button 
                      onClick={() => setCurrentWeekStart(startOfWeek(new Date(), { weekStartsOn: 1 }))}
                      className="px-4 py-2 bg-indigo-600/10 text-indigo-400 hover:bg-indigo-600 hover:text-white rounded-xl text-[10px] font-black uppercase tracking-widest transition-all"
                    >
                      Hoy
                    </button>
                    <button 
                      onClick={() => setCurrentWeekStart(prev => addWeeks(prev, 1))}
                      className="p-2.5 hover:bg-slate-800 rounded-xl transition-all text-slate-400 hover:text-white"
                      title="Semana Siguiente"
                    >
                      <ChevronRight size={20} />
                    </button>
                  </div>
                </div>

                {/* Payroll Summary Cards */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  {getEmployeeAnalysis().map(emp => (
                    <button 
                      key={emp.name} 
                      onClick={() => setSelectedEmployeeForAnalysis(selectedEmployeeForAnalysis === emp.name ? null : emp.name)}
                      className={`text-left bg-[#1e293b] p-8 rounded-[2.5rem] border transition-all duration-300 shadow-2xl relative overflow-hidden group ${selectedEmployeeForAnalysis === emp.name ? 'border-indigo-500 ring-2 ring-indigo-500/20 scale-[1.02]' : 'border-slate-700/50 hover:border-slate-600'}`}
                    >
                      <div className="absolute top-0 right-0 w-32 h-32 bg-indigo-500/5 rounded-bl-full -mr-12 -mt-12 transition-transform group-hover:scale-110" />
                      
                      <div className="relative z-10">
                        <div className="flex justify-between items-start mb-6">
                          <div className="flex items-center gap-4">
                            <div className={`w-16 h-16 rounded-3xl flex items-center justify-center text-2xl font-black border transition-colors ${selectedEmployeeForAnalysis === emp.name ? 'bg-indigo-500 text-white border-indigo-400' : 'bg-indigo-500/10 text-indigo-400 border-indigo-500/20'}`}>
                              {emp.name[0]}
                            </div>
                            <div>
                              <h3 className="text-xl font-black text-white uppercase tracking-wider">{emp.name}</h3>
                              <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Resumen Semanal</p>
                            </div>
                          </div>
                          <div className="text-right">
                            <span className="px-3 py-1 rounded-full bg-indigo-500/10 text-indigo-400 text-[10px] font-black uppercase tracking-widest border border-indigo-500/20">
                              {emp.days} Días
                            </span>
                          </div>
                        </div>

                        <div className="grid grid-cols-2 gap-4 sm:gap-6 mb-8">
                          <div className="p-4 sm:p-6 bg-slate-800/50 rounded-3xl border border-slate-700/30">
                            <p className="text-[9px] font-black text-slate-500 uppercase tracking-widest mb-2">Total Trabajado</p>
                            <p className="text-2xl sm:text-3xl font-black text-emerald-400 tracking-tighter">{emp.totalWorked.toFixed(1)}h</p>
                          </div>
                          <div className="p-4 sm:p-6 bg-slate-800/50 rounded-3xl border border-slate-700/30">
                            <p className="text-[9px] font-black text-slate-500 uppercase tracking-widest mb-2">Total Faltante</p>
                            <p className="text-2xl sm:text-3xl font-black text-rose-400 tracking-tighter">{emp.totalMissing.toFixed(1)}h</p>
                          </div>
                        </div>

                        <div className="space-y-3">
                          <div className="flex justify-between items-center text-[10px] font-black uppercase tracking-widest">
                            <span className="text-slate-500">Cumplimiento Semanal</span>
                            <span className="text-indigo-400">{((emp.totalWorked / (emp.totalWorked + emp.totalMissing)) * 100).toFixed(0)}%</span>
                          </div>
                          <div className="h-3 bg-slate-700 rounded-full overflow-hidden flex shadow-inner">
                            <div 
                              className="h-full bg-gradient-to-r from-emerald-600 to-emerald-400 transition-all duration-1000" 
                              style={{ width: `${(emp.totalWorked / (emp.totalWorked + emp.totalMissing)) * 100}%` }} 
                            />
                            <div 
                              className="h-full bg-rose-500/50" 
                              style={{ width: `${(emp.totalMissing / (emp.totalWorked + emp.totalMissing)) * 100}%` }} 
                            />
                          </div>
                        </div>
                        
                        <div className="mt-4 flex justify-center">
                          <span className="text-[8px] font-black text-indigo-400 uppercase tracking-[0.2em] animate-pulse">
                            {selectedEmployeeForAnalysis === emp.name ? 'Ver todos' : 'Click para filtrar gráfica'}
                          </span>
                        </div>
                      </div>
                    </button>
                  ))}
                </div>

                {/* Charts Grid */}
                <div className="grid grid-cols-1 gap-8">
                  <div className="bg-[#1e293b] p-4 sm:p-8 rounded-[2.5rem] border border-slate-700/50 shadow-2xl">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
                      <h3 className="text-sm font-black uppercase tracking-widest text-white flex items-center gap-2">
                        <BarChart3 className="text-indigo-400" size={18} /> 
                        {selectedEmployeeForAnalysis ? `Rendimiento: ${selectedEmployeeForAnalysis}` : 'Rendimiento General de la Semana'}
                      </h3>
                      {selectedEmployeeForAnalysis && (
                        <button 
                          onClick={() => setSelectedEmployeeForAnalysis(null)}
                          className="text-[10px] font-black text-rose-400 uppercase tracking-widest hover:text-rose-300 transition-colors"
                        >
                          Limpiar Filtro
                        </button>
                      )}
                    </div>
                    <div className="h-[300px] sm:h-[400px] w-full">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart data={
                          selectedEmployeeForAnalysis 
                            ? historicalRecords
                                .filter(r => r.empleado.includes(selectedEmployeeForAnalysis))
                                .map(r => {
                                  const config = configs.find(c => c.empleado === r.empleado);
                                  const stats = calculateRecordStats(r, config);
                                  return { fecha: r.fecha, worked: stats.worked, missing: stats.missing };
                                })
                            : getAnalysisData()
                        }>
                          <CartesianGrid strokeDasharray="3 3" stroke="#334155" vertical={false} />
                          <XAxis 
                            dataKey="fecha" 
                            stroke="#64748b" 
                            fontSize={10} 
                            tickFormatter={(val) => format(new Date(val + 'T12:00:00'), 'EEE d', { locale: es })}
                          />
                          <YAxis stroke="#64748b" fontSize={10} />
                          <Tooltip 
                            contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155', borderRadius: '12px' }}
                            itemStyle={{ fontSize: '12px', fontWeight: 'bold' }}
                            labelFormatter={(val) => format(new Date(val + 'T12:00:00'), "EEEE d 'de' MMMM", { locale: es })}
                          />
                          <Legend wrapperStyle={{ fontSize: '10px', fontWeight: 'black', textTransform: 'uppercase', paddingTop: '20px' }} />
                          <Bar dataKey="worked" name="Horas Trabajadas" fill="#6366f1" radius={[4, 4, 0, 0]} />
                          <Bar dataKey="missing" name="Horas Faltantes" fill="#f43f5e" radius={[4, 4, 0, 0]} />
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                  </div>
                </div>

                {/* Detailed Table */}
                <div className="bg-[#1e293b] rounded-[2.5rem] border border-slate-700/50 shadow-2xl overflow-hidden">
                  <div className="p-8 border-b border-slate-700/50 flex items-center justify-between">
                    <h2 className="text-lg font-black uppercase tracking-widest text-white">Detalle de Registros</h2>
                    <button className="flex items-center gap-2 text-[10px] font-black text-indigo-400 uppercase tracking-widest hover:text-indigo-300 transition-colors">
                      <Download size={14} /> Exportar CSV
                    </button>
                  </div>
                  <div className="overflow-x-auto">
                    <table className="w-full text-left border-collapse">
                      <thead>
                        <tr className="bg-slate-800/50 text-[10px] font-black text-slate-500 uppercase tracking-widest">
                          <th className="px-8 py-4">Fecha</th>
                          <th className="px-8 py-4">Empleado</th>
                          <th className="px-8 py-4">Entrada</th>
                          <th className="px-8 py-4">Salida</th>
                          <th className="px-8 py-4 text-right">Trabajadas</th>
                          <th className="px-8 py-4 text-right">Faltantes</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-700/30">
                        {historicalRecords.map(record => {
                          const config = configs.find(c => c.empleado === record.empleado);
                          const stats = calculateRecordStats(record, config);
                          return (
                            <tr key={record.id} className="hover:bg-slate-800/30 transition-colors">
                              <td className="px-8 py-4 text-xs font-bold text-slate-400">{record.fecha}</td>
                              <td className="px-8 py-4 text-xs font-black text-white uppercase tracking-wider">{record.empleado.split(' ')[1]}</td>
                              <td className="px-8 py-4 text-xs font-mono text-slate-300">{formatTime(record.entrada)}</td>
                              <td className="px-8 py-4 text-xs font-mono text-slate-300">{formatTime(record.salida)}</td>
                              <td className="px-8 py-4 text-right">
                                <span className="px-2 py-1 rounded-lg bg-emerald-500/10 text-emerald-400 text-[10px] font-black">
                                  {stats.worked.toFixed(2)}h
                                </span>
                              </td>
                              <td className="px-8 py-4 text-right">
                                <span className={`px-2 py-1 rounded-lg text-[10px] font-black ${stats.missing > 0 ? 'bg-rose-500/10 text-rose-400' : 'bg-slate-500/10 text-slate-500'}`}>
                                  {stats.missing.toFixed(2)}h
                                </span>
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            )}

            {adminSubTab === 'config' && (
              <div className="space-y-8">
                <div className="bg-[#1e293b] rounded-[2.5rem] border border-slate-700/50 shadow-2xl overflow-hidden">
                <div className="p-8 border-b border-slate-700/50">
                  <h2 className="text-lg font-black uppercase tracking-widest text-white flex items-center gap-3">
                    <Settings className="text-indigo-400" /> Configuración de Horarios
                  </h2>
                </div>
                <div className="p-8 grid grid-cols-1 md:grid-cols-2 gap-8">
                  {configs.map((config, idx) => (
                    <div key={idx} className="space-y-4 p-8 bg-slate-800/50 rounded-[2rem] border border-slate-700/30">
                      <div className="flex items-center gap-3 text-indigo-400 mb-6">
                        <div className="p-3 bg-indigo-500/10 rounded-2xl">
                          <User size={20} />
                        </div>
                        <h3 className="font-black uppercase text-xs tracking-[0.2em]">{config.empleado.split(' ')[1]}</h3>
                      </div>

                      <div className="grid grid-cols-2 gap-6">
                        <div className="space-y-3">
                          <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Entrada Programada</label>
                          <input 
                            type="time" 
                            value={config.entrada_programada}
                            onChange={(e) => {
                              const newConfigs = [...configs];
                              newConfigs[idx].entrada_programada = e.target.value;
                              setConfigs(newConfigs);
                            }}
                            className="w-full bg-[#0f172a] border border-slate-700 rounded-2xl px-4 py-3 text-sm text-white focus:outline-none focus:border-indigo-500 transition-colors"
                          />
                        </div>
                        <div className="space-y-3">
                          <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Salida Programada</label>
                          <input 
                            type="time" 
                            value={config.salida_programada}
                            onChange={(e) => {
                              const newConfigs = [...configs];
                              newConfigs[idx].salida_programada = e.target.value;
                              setConfigs(newConfigs);
                            }}
                            className="w-full bg-[#0f172a] border border-slate-700 rounded-2xl px-4 py-3 text-sm text-white focus:outline-none focus:border-indigo-500 transition-colors"
                          />
                        </div>
                      </div>

                      <div className="space-y-4 pt-4">
                        <div className="flex justify-between items-center">
                          <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Tiempo de Comida</label>
                          <span className="text-sm font-black text-indigo-400 bg-indigo-500/10 px-3 py-1 rounded-lg">{config.comida_minutos} min</span>
                        </div>
                        <input 
                          type="range" 
                          min="15" 
                          max="120" 
                          step="15"
                          value={config.comida_minutos}
                          onChange={(e) => {
                            const newConfigs = [...configs];
                            newConfigs[idx].comida_minutos = parseInt(e.target.value);
                            setConfigs(newConfigs);
                          }}
                          className="w-full h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-indigo-500"
                        />
                      </div>

                      <div className="space-y-4 pt-4 border-t border-slate-700/30">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <MapPin size={14} className="text-indigo-400" />
                            <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Verificación GPS</label>
                          </div>
                          <button 
                            onClick={() => {
                              const newConfigs = [...configs];
                              newConfigs[idx].gps_enabled = !newConfigs[idx].gps_enabled;
                              setConfigs(newConfigs);
                            }}
                            className={`w-10 h-5 rounded-full transition-all relative ${config.gps_enabled ? 'bg-indigo-600' : 'bg-slate-700'}`}
                          >
                            <div className={`absolute top-1 w-3 h-3 rounded-full bg-white transition-all ${config.gps_enabled ? 'left-6' : 'left-1'}`} />
                          </button>
                        </div>

                        {config.gps_enabled && (
                          <div className="space-y-4 animate-in fade-in slide-in-from-top-2 duration-300">
                            <div className="grid grid-cols-2 gap-4">
                              <div className="space-y-2">
                                <label className="text-[8px] font-black text-slate-500 uppercase tracking-widest">Latitud</label>
                                <input 
                                  type="number" 
                                  step="any"
                                  value={config.lat || 0}
                                  onChange={(e) => {
                                    const newConfigs = [...configs];
                                    newConfigs[idx].lat = parseFloat(e.target.value);
                                    setConfigs(newConfigs);
                                  }}
                                  className="w-full bg-[#0f172a] border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500"
                                />
                              </div>
                              <div className="space-y-2">
                                <label className="text-[8px] font-black text-slate-500 uppercase tracking-widest">Longitud</label>
                                <input 
                                  type="number" 
                                  step="any"
                                  value={config.lng || 0}
                                  onChange={(e) => {
                                    const newConfigs = [...configs];
                                    newConfigs[idx].lng = parseFloat(e.target.value);
                                    setConfigs(newConfigs);
                                  }}
                                  className="w-full bg-[#0f172a] border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500"
                                />
                              </div>
                            </div>
                            <div className="space-y-2">
                              <label className="text-[8px] font-black text-slate-500 uppercase tracking-widest">Radio (Metros)</label>
                              <input 
                                type="number" 
                                value={config.radius || 100}
                                onChange={(e) => {
                                  const newConfigs = [...configs];
                                  newConfigs[idx].radius = parseInt(e.target.value);
                                  setConfigs(newConfigs);
                                }}
                                className="w-full bg-[#0f172a] border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500"
                              />
                            </div>
                            <button 
                              onClick={() => {
                                setLoading(true);
                                navigator.geolocation.getCurrentPosition((pos) => {
                                  const newConfigs = [...configs];
                                  newConfigs[idx].lat = pos.coords.latitude;
                                  newConfigs[idx].lng = pos.coords.longitude;
                                  setConfigs(newConfigs);
                                  setLoading(false);
                                  showStatus('success', 'Ubicación actual obtenida');
                                }, (err) => {
                                  setLoading(false);
                                  showStatus('error', 'Error al obtener ubicación: ' + err.message);
                                });
                              }}
                              className="w-full py-2 bg-slate-700 hover:bg-slate-600 text-white rounded-xl text-[8px] font-black uppercase tracking-widest transition-all flex items-center justify-center gap-2"
                            >
                              <Navigation size={10} /> Capturar Ubicación Actual
                            </button>
                          </div>
                        )}
                      </div>

                      <button 
                        onClick={() => saveConfig(config)}
                        className="w-full mt-6 py-4 bg-indigo-600 hover:bg-indigo-500 text-white rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all shadow-lg shadow-indigo-500/20 active:scale-95"
                      >
                        Guardar Configuración
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
          </div>
        )}
      </div>

      {/* Loading Overlay */}
      {loading && (
        <div className="fixed inset-0 bg-[#0f172a]/60 backdrop-blur-md flex items-center justify-center z-[100]">
          <div className="bg-[#1e293b] p-8 rounded-[2rem] shadow-2xl border border-slate-700/50 flex flex-col items-center gap-4">
            <div className="relative w-12 h-12">
              <Loader2 className="animate-spin text-indigo-500 absolute inset-0" size={48} />
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="w-2 h-2 bg-indigo-500 rounded-full animate-pulse" />
              </div>
            </div>
            <span className="font-black text-[10px] text-indigo-400 uppercase tracking-[0.3em]">Procesando</span>
          </div>
        </div>
      )}
    </div>
  );
}

function ActionButton({ onClick, icon, label, color }: { onClick: () => void, icon: React.ReactNode, label: string, color: string }) {
  return (
    <button 
      onClick={onClick} 
      className={`w-full py-5 px-6 rounded-3xl text-white font-black flex items-center justify-center gap-4 shadow-xl active:scale-[0.98] transition-all duration-300 group border border-white/5 ${color}`}
    >
      <div className="transition-transform group-hover:scale-110">{icon}</div>
      <span className="text-[10px] uppercase tracking-[0.2em]">{label}</span>
    </button>
  );
}

interface AsistenciaRecord {
  id: string;
  empleado: string;
  fecha: string;
  entrada: string | null;
  salida_comida: string | null;
  regreso_comida: string | null;
  salida_personal: string | null;
  regreso_personal: string | null;
  salida: string | null;
  horas_trabajadas?: string;
  horas_faltantes?: string;
  lat_entrada?: number | null;
  lng_entrada?: number | null;
}

interface HorarioConfig {
  id?: string;
  empleado: string;
  entrada_programada: string;
  salida_programada: string;
  comida_minutos: number;
  lat?: number;
  lng?: number;
  radius?: number;
  gps_enabled?: boolean;
}
