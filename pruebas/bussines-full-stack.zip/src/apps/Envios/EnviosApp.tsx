import React, { useState, useEffect } from 'react';
import { 
  Truck, Package, CheckCircle2, Upload, Search, FileText,
  MapPin, Calendar, CreditCard, AlertCircle, BarChart3, Clock,
  Camera, CheckSquare, ShieldCheck, ChevronRight, LifeBuoy, Loader2
} from 'lucide-react';

const DB_CONFIG = {
  url: "https://api-datos.xtremediagnostics.com"
};

const GAS_API_URL = "https://script.google.com/macros/s/AKfycbxwHAlr9dfMoyW9Iej_CQ1Uf3IzNjL65hAegH8OQNrCp08awUXA8Nw9x_XowFcBMpTT/exec";

interface Cotizacion {
  id: number;
  contact_id: string;
  folio: string;
  monto: number;
  agente: string;
  created_at: string;
  detalles: any;
}

export default function EnviosApp({ username }: { username?: string }) {
  const [paidSales, setPaidSales] = useState<Cotizacion[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedSale, setSelectedSale] = useState<Cotizacion | null>(null);

  // Form state
  const [shippingMethod, setShippingMethod] = useState<'Paquetería' | 'Recolección Local'>('Paquetería');
  const [trackingNumber, setTrackingNumber] = useState('');
  const [paymentMethod, setPaymentMethod] = useState('');
  const [xtremeId, setXtremeId] = useState('');
  
  // Checklist
  const [chkManual, setChkManual] = useState(false);
  const [chkCharger, setChkCharger] = useState(false);
  const [chkBox, setChkBox] = useState(false);

  // Photos (simulated as boolean for UI completeness, in a real app these would be File objects or URLs)
  const [productPhoto, setProductPhoto] = useState<File | null>(null);
  const [clientTickets, setClientTickets] = useState<any[]>([]);
  const [loadingTickets, setLoadingTickets] = useState(false);

  useEffect(() => {
    if (selectedSale) {
      fetchClientTickets(selectedSale.contact_id);
    }
  }, [selectedSale]);

  const fetchClientTickets = async (clientId: string) => {
    setLoadingTickets(true);
    try {
      const res = await fetch(`${DB_CONFIG.url}/tickets?cliente_id=eq.${clientId}&order=created_at.desc`);
      if (res.ok) {
        const data = await res.json();
        setClientTickets(data);
      }
    } catch (e) {
      console.error('Error fetching client tickets:', e);
    } finally {
      setLoadingTickets(false);
    }
  };
  const [labelPhoto, setLabelPhoto] = useState<File | null>(null);
  const [barcodePhoto, setBarcodePhoto] = useState<File | null>(null);

  const [isSaving, setIsSaving] = useState(false);
  const [appError, setAppError] = useState<string | null>(null);
  const [appSuccess, setAppSuccess] = useState<string | null>(null);

  useEffect(() => {
    fetchPaidSales();
  }, []);

  const fetchPaidSales = async () => {
    try {
      setLoading(true);
      const res = await fetch(`${DB_CONFIG.url}/cotizaciones?select=id,contact_id,created_at,detalles,monto,agente,folio&order=created_at.desc&limit=1000`);
      if (res.ok) {
        const data = await res.json();
        if (Array.isArray(data)) {
          // Only paid quotes
          const paid = data.filter(s => s.detalles?.isPaid);
          setPaidSales(paid);
        }
      }
    } catch (error) {
      console.error("Error fetching paid sales:", error);
    } finally {
      setLoading(false);
    }
  };

  const filteredSales = paidSales.filter(sale => 
    (sale.detalles?.folio || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
    (sale.agente || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
    (sale.detalles?.vendedor || '').toLowerCase().includes(searchTerm.toLowerCase())
  );

  // Metrics
  const shippedSales = paidSales.filter(s => s.detalles?.envio?.estado === 'Enviado');
  const pendingShipping = paidSales.filter(s => s.detalles?.envio?.estado !== 'Enviado');

  const handleSelectSale = (sale: Cotizacion) => {
    setSelectedSale(sale);
    setShippingMethod(sale.detalles?.envio?.metodo || 'Paquetería');
    setTrackingNumber(sale.detalles?.envio?.guia || '');
    setPaymentMethod(sale.detalles?.paymentMethod || 'Transferencia');
    setXtremeId(sale.detalles?.envio?.xtremeId || '');
    setChkManual(sale.detalles?.envio?.chkManual || false);
    setChkCharger(sale.detalles?.envio?.chkCharger || false);
    setChkBox(sale.detalles?.envio?.chkBox || false);
    setProductPhoto(null);
    setLabelPhoto(null);
    setBarcodePhoto(null);
  };

  const hasLaptop = () => {
    if (!selectedSale?.detalles?.items) return false;
    return selectedSale.detalles.items.some((item: any) => 
      item.name && item.name.toLowerCase().startsWith('laptop')
    );
  };

  const handleSaveShipping = async () => {
    if (!selectedSale) return;
    
    const isLaptopIncluded = hasLaptop();
    if (isLaptopIncluded && !xtremeId.trim()) {
      setAppError("El Xtreme ID es obligatorio porque la venta incluye una Laptop.");
      return;
    }

    // All fields are now mandatory as requested
    if (!paymentMethod) {
      setAppError("El Método de Pago Confirmado es obligatorio.");
      return;
    }
    if (!trackingNumber.trim()) {
      setAppError("El Número de Guía es obligatorio.");
      return;
    }
    if (!productPhoto || !labelPhoto || !barcodePhoto) {
      setAppError("Todas las fotografías (Producto, Guía y Código de Barras) son obligatorias.");
      return;
    }

    setIsSaving(true);

    // Simulate Google Sheets Inventory Reduction
    await reduceInventoryInGoogleSheets(selectedSale);

    const updatedDetalles = {
      ...selectedSale.detalles,
      envio: {
        metodo: shippingMethod,
        guia: trackingNumber,
        paymentMethod,
        xtremeId,
        chkManual,
        chkCharger,
        chkBox,
        productPhotoName: productPhoto?.name || '',
        labelPhotoName: labelPhoto?.name || '',
        barcodePhotoName: barcodePhoto?.name || '',
        fechaEnvio: new Date().toISOString(),
        estado: 'Enviado'
      }
    };

    try {
      const res = await fetch(`${DB_CONFIG.url}/cotizaciones?id=eq.${selectedSale.id}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ detalles: updatedDetalles })
      });

      if (res.ok) {
        setPaidSales(prev => prev.map(s => 
          s.id === selectedSale.id ? { ...s, detalles: updatedDetalles } : s
        ));
        setSelectedSale(null);
        setAppSuccess("Envío registrado e inventario actualizado correctamente.");
      } else {
        setAppError("Error al guardar la información de envío.");
      }
    } catch (e) {
      console.error("Error saving shipping info", e);
      setAppError("Error al guardar la información de envío.");
    } finally {
      setIsSaving(false);
    }
  };

  const reduceInventoryInGoogleSheets = async (sale: Cotizacion) => {
    console.log("Iniciando reducción de inventario en Google Sheets...");
    
    const items = sale.detalles?.items || [];
    const itemsToReduce: { name: string, qty: number }[] = [];
    
    for (const item of items) {
      const itemName = item.name || '';
      const qty = item.qty || 1;
      
      itemsToReduce.push({ name: itemName, qty });
      
      if (itemName.toLowerCase().startsWith('laptop')) {
        // Reduce accessories based on laptop model
        itemsToReduce.push({ name: 'Disco Duro 512GB', qty: qty });
        
        if (itemName.toLowerCase().includes('panasonic') || itemName.toLowerCase().includes('cf-31') || itemName.toLowerCase().includes('cf-30')) {
          itemsToReduce.push({ name: 'Cargador Panasonic Toughbook', qty: qty });
          itemsToReduce.push({ name: 'Caddy disco duro Pansonic Toughbook CF-31, CF-30', qty: qty });
        } else if (itemName.toLowerCase().includes('dell') || itemName.toLowerCase().includes('rugged')) {
          itemsToReduce.push({ name: 'Cargador Dell punta grande', qty: qty });
          itemsToReduce.push({ name: 'Caddy disco duro Dell Rugged 5414, 5404, 7404, 7414', qty: qty });
        } else if (itemName.toLowerCase().includes('getac') || itemName.toLowerCase().includes('b-300') || itemName.toLowerCase().includes('b300')) {
          itemsToReduce.push({ name: 'Cargador Toshiba / GETAC', qty: qty });
          itemsToReduce.push({ name: 'Caddy disco duro Getac B-300', qty: qty });
        }
      }
    }

    try {
      const res = await fetch(GAS_API_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'text/plain;charset=utf-8' },
        body: JSON.stringify({ 
          action: 'reduceInventory', 
          items: itemsToReduce,
          folio: sale.detalles?.folio
        })
      });
      const data = await res.json();
      console.log("Respuesta de Apps Script (Inventario):", data);
    } catch (error) {
      console.error("Error al reducir inventario en Apps Script:", error);
      // We don't throw here to allow the shipping process to complete even if inventory fails
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>, setter: React.Dispatch<React.SetStateAction<File | null>>) => {
    if (e.target.files && e.target.files[0]) {
      setter(e.target.files[0]);
    }
  };

  if (loading && paidSales.length === 0) {
    return (
      <div className="h-full flex items-center justify-center bg-[#0f1014]">
        <div className="w-8 h-8 border-2 border-blue-500 border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  return (
    <div className="h-full flex flex-col bg-[#0f1014] text-slate-300 font-sans overflow-hidden">
      
      {/* Top Header */}
      <div className="px-6 py-4 border-b border-[#1f2026] flex flex-col sm:flex-row sm:items-center justify-between shrink-0 bg-[#15161a] gap-4">
        <div className="flex items-center gap-4">
          <div className="w-10 h-10 bg-blue-500/10 rounded-xl flex items-center justify-center border border-blue-500/20">
            <Truck className="text-blue-400 w-5 h-5" />
          </div>
          <div>
            <h1 className="text-lg font-bold text-white tracking-wide">XtremeOS <span className="text-blue-400">Envíos</span></h1>
            <p className="text-xs text-slate-500 uppercase tracking-widest">Logística y Despacho</p>
          </div>
        </div>

        <div className="relative w-full sm:w-72">
          <Search className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
          <input 
            type="text" 
            placeholder="Buscar por folio o agente..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-4 py-2 bg-[#1f2026] border border-[#2a2b32] text-white text-sm focus:bg-[#1a1b20] focus:border-blue-500 focus:ring-1 focus:ring-blue-500 rounded-lg transition-all outline-none"
          />
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 overflow-hidden flex flex-col md:flex-row max-w-7xl mx-auto w-full p-4 md:p-6 gap-6">
        
        {/* List of Paid Quotes */}
        <div className="w-full md:w-1/3 flex flex-col bg-[#15161a] rounded-2xl border border-[#1f2026] overflow-hidden shrink-0 h-[40vh] md:h-auto">
          <div className="px-5 py-4 border-b border-[#1f2026] bg-[#1a1b20]">
            <h3 className="font-bold text-white flex items-center gap-2 text-sm uppercase tracking-wider">
              <Package className="text-blue-400 w-4 h-4" />
              Ventas Pagadas
            </h3>
          </div>
          <div className="flex-1 overflow-y-auto p-3 space-y-2">
            {filteredSales.length === 0 ? (
              <div className="text-center py-8 text-slate-500 text-sm">
                No hay ventas pagadas pendientes.
              </div>
            ) : (
              filteredSales.map(sale => {
                const isShipped = sale.detalles?.envio?.estado === 'Enviado';
                return (
                  <div 
                    key={sale.id} 
                    onClick={() => handleSelectSale(sale)}
                    className={`p-3 rounded-xl border cursor-pointer transition-all ${
                      selectedSale?.id === sale.id 
                        ? 'bg-blue-500/10 border-blue-500/30' 
                        : 'bg-[#1a1b20] border-[#2a2b32] hover:border-[#3a3b42]'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-bold text-white text-sm">{sale.detalles?.folio || 'S/F'}</span>
                      {isShipped ? (
                        <span className="text-[9px] px-2 py-0.5 rounded-md bg-emerald-500/10 text-emerald-400 font-bold uppercase tracking-wider border border-emerald-500/20">
                          Enviado
                        </span>
                      ) : (
                        <span className="text-[9px] px-2 py-0.5 rounded-md bg-amber-500/10 text-amber-400 font-bold uppercase tracking-wider border border-amber-500/20">
                          Pendiente
                        </span>
                      )}
                    </div>
                    <div className="text-xs text-slate-500 flex items-center justify-between">
                      <span className="flex items-center gap-1">
                        <Calendar className="w-3 h-3" />
                        {sale.detalles?.paymentDate ? new Date(sale.detalles.paymentDate).toLocaleDateString('es-MX') : 'Sin fecha'}
                      </span>
                      <span className="text-slate-400 font-medium">${(sale.monto || sale.detalles?.total || 0).toLocaleString('es-MX', { minimumFractionDigits: 2 })}</span>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>

        {/* Shipping Details Form */}
        <div className="flex-1 bg-[#15161a] rounded-2xl border border-[#1f2026] overflow-hidden flex flex-col h-[60vh] md:h-auto">
          {selectedSale ? (
            <div className="flex-1 overflow-y-auto p-5 md:p-8 custom-scrollbar">
              <div className="flex flex-col md:flex-row md:items-center justify-between mb-6 pb-6 border-b border-[#1f2026] gap-4">
                <div>
                  <h2 className="text-xl md:text-2xl font-black text-white mb-2">
                    Despacho: {selectedSale.detalles?.folio || 'S/F'}
                  </h2>
                  <div className="flex flex-wrap items-center gap-3 text-xs text-slate-400 font-medium">
                    <span className="flex items-center gap-1 bg-[#1a1b20] px-2 py-1 rounded-md border border-[#2a2b32]"><CreditCard className="w-3 h-3" /> {selectedSale.detalles?.paymentMethod || 'Transferencia'}</span>
                    <span className="flex items-center gap-1 bg-[#1a1b20] px-2 py-1 rounded-md border border-[#2a2b32]"><Calendar className="w-3 h-3" /> {selectedSale.detalles?.paymentDate ? new Date(selectedSale.detalles.paymentDate).toLocaleDateString('es-MX') : 'N/A'}</span>
                    <span className="flex items-center gap-1 bg-[#1a1b20] px-2 py-1 rounded-md border border-[#2a2b32]"><Package className="w-3 h-3" /> {selectedSale.detalles?.items?.length || 0} Artículos</span>
                  </div>
                </div>
                <div className="text-left md:text-right bg-[#1a1b20] p-3 rounded-xl border border-[#2a2b32]">
                  <div className="text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">Monto Pagado</div>
                  <div className="text-xl font-black text-emerald-400">${(selectedSale.monto || selectedSale.detalles?.total || 0).toLocaleString('es-MX', { minimumFractionDigits: 2 })}</div>
                </div>
              </div>

              <div className="space-y-8">
                {/* Section 1: Payment & Xtreme ID */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Método de Pago Confirmado</label>
                    <select 
                      value={paymentMethod}
                      onChange={(e) => setPaymentMethod(e.target.value)}
                      className="w-full px-4 py-2.5 bg-[#1a1b20] border border-[#2a2b32] text-white rounded-xl focus:ring-1 focus:ring-blue-500 outline-none text-sm"
                    >
                      <option value="">Seleccionar...</option>
                      <option value="Transferencia">Transferencia</option>
                      <option value="Efectivo">Efectivo</option>
                      <option value="Terminal Punto de Venta">Terminal Punto de Venta</option>
                      <option value="Mercado Libre">Mercado Libre</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">
                      Xtreme ID {hasLaptop() && <span className="text-red-400 ml-1">*Obligatorio (Laptop)</span>}
                    </label>
                    <input 
                      type="text" 
                      value={xtremeId}
                      onChange={(e) => setXtremeId(e.target.value)}
                      placeholder="Ej. NX-10293"
                      className={`w-full px-4 py-2.5 bg-[#1a1b20] border text-white rounded-xl focus:ring-1 outline-none text-sm transition-colors ${hasLaptop() && !xtremeId.trim() ? 'border-red-500/50 focus:ring-red-500' : 'border-[#2a2b32] focus:ring-blue-500 focus:border-blue-500'}`}
                    />
                  </div>
                </div>

                {/* Section 2: Photos */}
                <div>
                  <h3 className="text-sm font-bold text-white flex items-center gap-2 mb-4 uppercase tracking-wider border-b border-[#1f2026] pb-2">
                    <Camera className="text-blue-400 w-4 h-4" />
                    Evidencia Fotográfica
                  </h3>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    {/* Product Photo */}
                    <div className="border border-dashed border-[#2a2b32] rounded-xl p-4 flex flex-col items-center justify-center text-center hover:bg-[#1a1b20] transition-colors cursor-pointer relative overflow-hidden group">
                      {productPhoto ? (
                        <div className="absolute inset-0 bg-[#1a1b20] flex flex-col items-center justify-center">
                          <CheckCircle2 className="w-8 h-8 text-emerald-400 mb-2" />
                          <span className="text-xs text-emerald-400 font-medium truncate px-2 w-full">{productPhoto.name}</span>
                        </div>
                      ) : (
                        <>
                          <div className="w-10 h-10 bg-[#1f2026] text-slate-400 rounded-full flex items-center justify-center mb-2 group-hover:text-blue-400 transition-colors">
                            <Package className="w-5 h-5" />
                          </div>
                          <p className="font-bold text-slate-300 text-xs mb-1">Foto del Producto</p>
                          <p className="text-[10px] text-slate-500">Obligatorio</p>
                        </>
                      )}
                      <input type="file" accept="image/*" onChange={(e) => handleFileUpload(e, setProductPhoto)} className="absolute inset-0 opacity-0 cursor-pointer" />
                    </div>

                    {/* Label Photo */}
                    <div className="border border-dashed border-[#2a2b32] rounded-xl p-4 flex flex-col items-center justify-center text-center hover:bg-[#1a1b20] transition-colors cursor-pointer relative overflow-hidden group">
                      {labelPhoto ? (
                        <div className="absolute inset-0 bg-[#1a1b20] flex flex-col items-center justify-center">
                          <CheckCircle2 className="w-8 h-8 text-emerald-400 mb-2" />
                          <span className="text-xs text-emerald-400 font-medium truncate px-2 w-full">{labelPhoto.name}</span>
                        </div>
                      ) : (
                        <>
                          <div className="w-10 h-10 bg-[#1f2026] text-slate-400 rounded-full flex items-center justify-center mb-2 group-hover:text-blue-400 transition-colors">
                            <FileText className="w-5 h-5" />
                          </div>
                          <p className="font-bold text-slate-300 text-xs mb-1">Hoja / Ticket Envío</p>
                          <p className="text-[10px] text-slate-500">Obligatorio</p>
                        </>
                      )}
                      <input type="file" accept="image/*" onChange={(e) => handleFileUpload(e, setLabelPhoto)} className="absolute inset-0 opacity-0 cursor-pointer" />
                    </div>

                    {/* Barcode Photo */}
                    <div className="border border-dashed border-[#2a2b32] rounded-xl p-4 flex flex-col items-center justify-center text-center hover:bg-[#1a1b20] transition-colors cursor-pointer relative overflow-hidden group">
                      {barcodePhoto ? (
                        <div className="absolute inset-0 bg-[#1a1b20] flex flex-col items-center justify-center">
                          <CheckCircle2 className="w-8 h-8 text-emerald-400 mb-2" />
                          <span className="text-xs text-emerald-400 font-medium truncate px-2 w-full">{barcodePhoto.name}</span>
                        </div>
                      ) : (
                        <>
                          <div className="w-10 h-10 bg-[#1f2026] text-slate-400 rounded-full flex items-center justify-center mb-2 group-hover:text-blue-400 transition-colors">
                            <BarChart3 className="w-5 h-5" />
                          </div>
                          <p className="font-bold text-slate-300 text-xs mb-1">Código de Barras</p>
                          <p className="text-[10px] text-slate-500">Obligatorio</p>
                        </>
                      )}
                      <input type="file" accept="image/*" onChange={(e) => handleFileUpload(e, setBarcodePhoto)} className="absolute inset-0 opacity-0 cursor-pointer" />
                    </div>
                  </div>
                </div>

                {/* Section 3: Checklist */}
                <div>
                  <h3 className="text-sm font-bold text-white flex items-center gap-2 mb-4 uppercase tracking-wider border-b border-[#1f2026] pb-2">
                    <CheckSquare className="text-blue-400 w-4 h-4" />
                    Checklist de Envío
                  </h3>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <label className={`flex items-center gap-3 p-3 rounded-xl border cursor-pointer transition-colors ${chkManual ? 'bg-blue-500/10 border-blue-500/30' : 'bg-[#1a1b20] border-[#2a2b32] hover:border-[#3a3b42]'}`}>
                      <input type="checkbox" checked={chkManual} onChange={(e) => setChkManual(e.target.checked)} className="w-4 h-4 rounded text-blue-500 focus:ring-blue-500 bg-[#1f2026] border-[#2a2b32]" />
                      <span className={`text-sm font-medium ${chkManual ? 'text-blue-400' : 'text-slate-300'}`}>Manual Impreso</span>
                    </label>
                    <label className={`flex items-center gap-3 p-3 rounded-xl border cursor-pointer transition-colors ${chkCharger ? 'bg-blue-500/10 border-blue-500/30' : 'bg-[#1a1b20] border-[#2a2b32] hover:border-[#3a3b42]'}`}>
                      <input type="checkbox" checked={chkCharger} onChange={(e) => setChkCharger(e.target.checked)} className="w-4 h-4 rounded text-blue-500 focus:ring-blue-500 bg-[#1f2026] border-[#2a2b32]" />
                      <span className={`text-sm font-medium ${chkCharger ? 'text-blue-400' : 'text-slate-300'}`}>Cargador</span>
                    </label>
                    <label className={`flex items-center gap-3 p-3 rounded-xl border cursor-pointer transition-colors ${chkBox ? 'bg-blue-500/10 border-blue-500/30' : 'bg-[#1a1b20] border-[#2a2b32] hover:border-[#3a3b42]'}`}>
                      <input type="checkbox" checked={chkBox} onChange={(e) => setChkBox(e.target.checked)} className="w-4 h-4 rounded text-blue-500 focus:ring-blue-500 bg-[#1f2026] border-[#2a2b32]" />
                      <span className={`text-sm font-medium ${chkBox ? 'text-blue-400' : 'text-slate-300'}`}>Caja Original/Empaque</span>
                    </label>
                  </div>
                </div>

                {/* Section 4: Shipping Method */}
                <div>
                  <h3 className="text-sm font-bold text-white flex items-center gap-2 mb-4 uppercase tracking-wider border-b border-[#1f2026] pb-2">
                    <Truck className="text-blue-400 w-4 h-4" />
                    Datos de Paquetería
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="flex gap-3">
                      <label className={`flex-1 p-3 rounded-xl border cursor-pointer transition-all flex items-center justify-center gap-2 ${shippingMethod === 'Paquetería' ? 'border-blue-500/50 bg-blue-500/10' : 'border-[#2a2b32] bg-[#1a1b20] hover:border-[#3a3b42]'}`}>
                        <input type="radio" name="shippingMethod" value="Paquetería" checked={shippingMethod === 'Paquetería'} onChange={() => setShippingMethod('Paquetería')} className="sr-only" />
                        <Truck className={`w-4 h-4 ${shippingMethod === 'Paquetería' ? 'text-blue-400' : 'text-slate-500'}`} />
                        <div className={`text-sm font-bold ${shippingMethod === 'Paquetería' ? 'text-blue-400' : 'text-slate-400'}`}>Paquetería</div>
                      </label>
                      <label className={`flex-1 p-3 rounded-xl border cursor-pointer transition-all flex items-center justify-center gap-2 ${shippingMethod === 'Recolección Local' ? 'border-blue-500/50 bg-blue-500/10' : 'border-[#2a2b32] bg-[#1a1b20] hover:border-[#3a3b42]'}`}>
                        <input type="radio" name="shippingMethod" value="Recolección Local" checked={shippingMethod === 'Recolección Local'} onChange={() => setShippingMethod('Recolección Local')} className="sr-only" />
                        <MapPin className={`w-4 h-4 ${shippingMethod === 'Recolección Local' ? 'text-blue-400' : 'text-slate-500'}`} />
                        <div className={`text-sm font-bold ${shippingMethod === 'Recolección Local' ? 'text-blue-400' : 'text-slate-400'}`}>Local</div>
                      </label>
                    </div>

                    {shippingMethod === 'Paquetería' && (
                      <div>
                        <input 
                          type="text" 
                          value={trackingNumber}
                          onChange={(e) => setTrackingNumber(e.target.value)}
                          placeholder="Número de Guía (Ej. 1Z999...)"
                          className="w-full px-4 py-3 bg-[#1a1b20] border border-[#2a2b32] text-white rounded-xl focus:ring-1 focus:ring-blue-500 focus:border-blue-500 outline-none text-sm"
                        />
                      </div>
                    )}
                  </div>
                </div>

                {/* Resumen de Tickets de Soporte */}
                <div className="pt-4 border-t border-[#1f2026]">
                  <h3 className="text-sm font-bold text-white flex items-center gap-2 mb-4 uppercase tracking-wider">
                    <LifeBuoy className="text-orange-400 w-4 h-4" />
                    Historial de Soporte del Cliente
                  </h3>
                  {loadingTickets ? (
                    <div className="flex items-center gap-2 text-xs text-slate-500">
                      <Loader2 size={12} className="animate-spin" /> Cargando tickets...
                    </div>
                  ) : clientTickets.length > 0 ? (
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-h-48 overflow-y-auto pr-2 custom-scrollbar">
                      {clientTickets.map((ticket) => (
                        <div key={ticket.id} className="p-3 bg-[#1a1b20] border border-[#2a2b32] rounded-xl flex flex-col gap-1">
                          <div className="flex justify-between items-start">
                            <span className="text-[10px] font-bold text-slate-500">#{ticket.id}</span>
                            <span className={`text-[9px] px-1.5 py-0.5 rounded-full font-bold uppercase ${
                              ticket.estado === 'Abierto' ? 'bg-red-500/10 text-red-500' : 'bg-emerald-500/10 text-emerald-500'
                            }`}>
                              {ticket.estado}
                            </span>
                          </div>
                          <p className="text-xs font-bold text-white truncate">{ticket.titulo}</p>
                          <p className="text-[10px] text-slate-500">{new Date(ticket.created_at).toLocaleDateString('es-MX')}</p>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-xs text-slate-500 italic">No se encontraron tickets de soporte para este cliente.</p>
                  )}
                </div>

                {/* Archivos Adjuntos (Etiqueta y Factura) */}
                {(selectedSale.detalles?.shipping_label_url || selectedSale.detalles?.invoice_url) && (
                  <div className="pt-4 border-t border-[#1f2026]">
                    <h3 className="text-sm font-bold text-white flex items-center gap-2 mb-4 uppercase tracking-wider">
                      <FileText className="text-blue-400 w-4 h-4" />
                      Documentación del Pedido
                    </h3>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      {selectedSale.detalles?.shipping_label_url && (
                        <a 
                          href={selectedSale.detalles.shipping_label_url} 
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="flex items-center gap-3 p-3 bg-blue-500/5 border border-blue-500/20 rounded-xl hover:bg-blue-500/10 transition-colors group"
                        >
                          <div className="w-8 h-8 rounded-lg bg-blue-500/20 flex items-center justify-center text-blue-400 group-hover:scale-110 transition-transform">
                            <FileText size={16} />
                          </div>
                          <div className="flex flex-col">
                            <span className="text-xs font-bold text-blue-400 uppercase tracking-tighter">Etiqueta de Envío</span>
                            <span className="text-[9px] text-slate-500 uppercase font-black">Ver Documento PDF</span>
                          </div>
                        </a>
                      )}
                      {selectedSale.detalles?.invoice_url && (
                        <a 
                          href={selectedSale.detalles.invoice_url} 
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="flex items-center gap-3 p-3 bg-emerald-500/5 border border-emerald-500/20 rounded-xl hover:bg-emerald-500/10 transition-colors group"
                        >
                          <div className="w-8 h-8 rounded-lg bg-emerald-500/20 flex items-center justify-center text-emerald-400 group-hover:scale-110 transition-transform">
                            <FileText size={16} />
                          </div>
                          <div className="flex flex-col">
                            <span className="text-xs font-bold text-emerald-400 uppercase tracking-tighter">Factura / XML</span>
                            <span className="text-[9px] text-slate-500 uppercase font-black">Ver Documentación</span>
                          </div>
                        </a>
                      )}
                    </div>
                  </div>
                )}

              </div>
            </div>
          ) : (
            <div className="flex-1 flex flex-col items-center justify-center text-slate-500 p-8">
              <div className="w-16 h-16 bg-[#1a1b20] rounded-full flex items-center justify-center mb-4 border border-[#2a2b32]">
                <Package className="w-8 h-8 text-slate-600" />
              </div>
              <p className="font-bold text-lg text-slate-400 mb-1">Selecciona una venta</p>
              <p className="text-sm text-center max-w-xs">Elige una venta pagada del panel izquierdo para gestionar su envío y actualizar el inventario.</p>
            </div>
          )}
          
          {/* Footer Actions */}
          {selectedSale && (
            <div className="p-4 border-t border-[#1f2026] bg-[#15161a] shrink-0 flex justify-end">
              <button 
                onClick={handleSaveShipping}
                disabled={isSaving}
                className="px-6 py-2.5 bg-blue-600 text-white rounded-xl font-bold hover:bg-blue-500 transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2 shadow-lg shadow-blue-500/20 text-sm"
              >
                {isSaving ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                    Guardando...
                  </>
                ) : (
                  <>
                    <ShieldCheck className="w-4 h-4" />
                    Confirmar Envío y Descontar Inventario
                  </>
                )}
              </button>
            </div>
          )}
        </div>

      </div>

      {/* Integrated Error Modal */}
      {appError && (
        <div className="fixed inset-0 z-[300] bg-slate-950/90 backdrop-blur-xl flex items-center justify-center p-4">
          <div className="bg-[#1a1b20] border border-red-500/30 rounded-3xl w-full max-w-sm overflow-hidden shadow-2xl animate-in zoom-in-95 duration-200">
            <div className="p-8 text-center">
              <div className="w-16 h-16 bg-red-500/10 rounded-2xl flex items-center justify-center mb-6 mx-auto">
                <AlertCircle className="text-red-500" size={32} />
              </div>
              <h3 className="text-xl font-black text-white uppercase tracking-widest mb-2">Error</h3>
              <p className="text-slate-400 text-sm leading-relaxed mb-8">
                {appError}
              </p>
              <button 
                onClick={() => setAppError(null)}
                className="w-full py-4 bg-red-600 text-white rounded-2xl font-black text-[10px] uppercase tracking-widest hover:bg-red-500 transition-all shadow-lg shadow-red-500/20 active:scale-95"
              >
                Entendido
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Integrated Success Modal */}
      {appSuccess && (
        <div className="fixed inset-0 z-[300] bg-slate-950/90 backdrop-blur-xl flex items-center justify-center p-4">
          <div className="bg-[#1a1b20] border border-emerald-500/30 rounded-3xl w-full max-w-sm overflow-hidden shadow-2xl animate-in zoom-in-95 duration-200">
            <div className="p-8 text-center">
              <div className="w-16 h-16 bg-emerald-500/10 rounded-2xl flex items-center justify-center mb-6 mx-auto">
                <CheckCircle2 className="text-emerald-500" size={32} />
              </div>
              <h3 className="text-xl font-black text-white uppercase tracking-widest mb-2">Éxito</h3>
              <p className="text-slate-400 text-sm leading-relaxed mb-8">
                {appSuccess}
              </p>
              <button 
                onClick={() => setAppSuccess(null)}
                className="w-full py-4 bg-emerald-600 text-white rounded-2xl font-black text-[10px] uppercase tracking-widest hover:bg-emerald-500 transition-all shadow-lg shadow-emerald-500/20 active:scale-95"
              >
                Continuar
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
